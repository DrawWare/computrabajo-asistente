"""Filtros de avisos: exclusión por palabras clave y reglas de modalidad / idioma.

``evaluate_job`` es el punto de entrada: devuelve el motivo de descarte o None si el aviso pasa.
Módulo puro: no depende de Playwright ni de la red.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Iterable

# ---------------------------------------------------------------------------
# Reglas fijas (spec: modalidad, geografía e idioma). Se comparan normalizadas (sin tildes).
# ---------------------------------------------------------------------------

REMOTE_TERMS = ("remoto", "remota", "teletrabajo", "home office", "100% remoto", "100% remota", "work from home")
HYBRID_TERMS = ("hibrido", "hibrida", "mixto", "mixta", "semipresencial")  # femenino: avisos suelen usarlo
PRESENCIAL_TERMS = ("presencial",)
CORDOBA_TERMS = ("cordoba",)
ZONA_SUR_TERMS = (
    "zona sur", "barrio jardin", "ciudad universitaria", "nueva cordoba",
    "av. velez sarsfield", "av. valparaiso", "camino san carlos", "camino a san antonio",
    "ferreyra", "jockey", "roca", "guemes",
)
ENGLISH_BLOCK_TERMS = ("ingles avanzado", "ingles bilingue", "c1", "c2", "fluent english")

MODALITIES = ("remoto", "hibrido", "presencial")


@dataclass(frozen=True)
class LocationRules:
    """Reglas de ubicación y modalidad configurables (6.2.1). Defaults = Córdoba, ver DEFAULT_LOCATION.

    ``home_terms``: lugares donde vive la persona (la modalidad híbrida/presencial se acepta ahí).
    ``zone_terms``: zona aceptable para presencial en el lugar de origen; vacío = cualquier lugar de origen.
    ``modalities``: modalidades que se buscan (subconjunto de MODALITIES).
    ``legacy_codes``: usa los códigos históricos (``hibrido_fuera_cordoba``, ``presencial_fuera_zona_sur``).
    """

    home_terms: tuple[str, ...]
    zone_terms: tuple[str, ...]
    modalities: tuple[str, ...]
    legacy_codes: bool = False


DEFAULT_LOCATION = LocationRules(CORDOBA_TERMS, ZONA_SUR_TERMS, MODALITIES, legacy_codes=True)


def normalize(text: str) -> str:
    """Minúsculas, sin tildes/diacríticos y con espacios colapsados.

    Ejemplo: "Pasantía  TÉCNICA" -> "pasantia tecnica".
    """
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return " ".join(stripped.lower().split())


def keyword_pattern(keyword: str) -> re.Pattern[str]:
    """Regex de palabra completa para una keyword ya normalizable.

    Usa lookarounds en vez de \\b para que keywords con bordes no alfanuméricos
    también funcionen. "it" no matchea "item"; sí matchea "Técnico IT" y "(IT)".
    """
    return re.compile(rf"(?<!\w){re.escape(normalize(keyword))}(?!\w)")


def is_excluded(
    title: str,
    description: str | None,
    keywords: Iterable[str],
) -> str | None:
    """Devuelve la keyword (tal como está en config) que excluye el aviso, o None."""
    haystack = normalize(f"{title or ''} {description or ''}")
    for keyword in keywords:
        if not keyword or not keyword.strip():
            continue
        if keyword_pattern(keyword).search(haystack):
            return keyword
    return None


def _find(terms: Iterable[str], text: str) -> str | None:
    return is_excluded("", text, terms)


def _location_code(rules: LocationRules, new: str, legacy: str) -> str:
    return legacy if rules.legacy_codes else new


def modality_problem(text: str, rules: LocationRules = DEFAULT_LOCATION) -> str | None:
    """Regla geográfica y de modalidad. None = aceptable; si no, motivo de descarte.

    - Remoto / teletrabajo / home office: aceptable en todo el país si "remoto" está en ``rules.modalities``.
    - Híbrido, mixto o semipresencial: aceptable solo si el aviso es del lugar de origen (``rules.home_terms``).
    - Presencial: aceptable en el lugar de origen y en la zona (``rules.zone_terms``; vacía = cualquier zona).
    - Sin modalidad clara: se descarta (criterio conservador).
    Con ``DEFAULT_LOCATION`` (legacy_codes) los motivos son los históricos de Córdoba.
    """
    if _find(REMOTE_TERMS, text):
        return None if "remoto" in rules.modalities else "remoto_no_buscado"
    home = _find(rules.home_terms, text)
    if _find(HYBRID_TERMS, text):
        if "hibrido" not in rules.modalities:
            return "hibrido_no_buscado"
        if home:
            return None
        return _location_code(rules, "hibrido_fuera_de_zona", "hibrido_fuera_cordoba")
    if "presencial" in rules.modalities and home and (not rules.zone_terms or _find(rules.zone_terms, text)):
        return None
    if _find(PRESENCIAL_TERMS, text):
        if "presencial" not in rules.modalities:
            return "presencial_no_buscado"
        return _location_code(rules, "presencial_fuera_de_zona", "presencial_fuera_zona_sur")
    return "modalidad_no_clara"


def english_problem(text: str, terms: Iterable[str] = ENGLISH_BLOCK_TERMS) -> str | None:
    """Descarta si el aviso exige inglés avanzado / bilingüe / C1 / C2 (o los ``terms`` configurados)."""
    term = _find(terms, text)
    return f"ingles:{term}" if term else None


def title_problem(
    title: str,
    *,
    title_keywords: Iterable[str],
    required_keywords: Iterable[str] = (),
) -> str | None:
    """Descarte solo por título (sin descripción): palabra excluida, o ningún término de perfil.

    ``required_keywords`` vacío => no se exige ningún término. Si no vacío, el título debe contener al
    menos uno (palabra completa): así un aviso ajeno al perfil se descarta sin abrirlo.
    """
    keyword = is_excluded(title, None, title_keywords)
    if keyword:
        return f"titulo:{keyword}"
    required = [k for k in required_keywords if k and k.strip()]
    if required and not is_excluded(title, None, required):
        return "titulo_fuera_de_perfil"
    return None


def evaluate_job(
    title: str,
    description: str | None,
    *,
    title_keywords: Iterable[str],
    desc_keywords: Iterable[str],
    location: str = "",
    required_title_keywords: Iterable[str] = (),
    location_rules: LocationRules = DEFAULT_LOCATION,
    english_terms: Iterable[str] = ENGLISH_BLOCK_TERMS,
) -> str | None:
    """Motivo de descarte del aviso, o None si pasa todos los filtros.

    Orden: título (excluidas y requeridas) > descripción (frases) > modalidad/geografía > inglés.
    ``location`` es el texto de ubicación de la tarjeta, si se pudo leer.
    """
    problem = title_problem(
        title,
        title_keywords=title_keywords,
        required_keywords=required_title_keywords,
    )
    if problem:
        return problem

    keyword = is_excluded("", description, desc_keywords)
    if keyword:
        return f"descripcion:{keyword}"

    text = f"{title or ''} {description or ''} {location or ''}"
    problem = modality_problem(text, location_rules)
    if problem:
        return problem

    return english_problem(text, english_terms)
