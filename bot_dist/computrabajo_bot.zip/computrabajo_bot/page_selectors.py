"""TODOS los selectores del sitio ar.computrabajo.com, en un solo lugar.

Módulo nombrado ``page_selectors`` (no ``selectors``) para no pisar la stdlib
``selectors`` que usa asyncio/Playwright. Ver PLAN.md, "Decisiones de arquitectura".

Convención:
- Cada constante lleva un comentario con la parte de la página a la que apunta.
- Preferir role / texto visible / data-* / aria-*. Evitar clases ofuscadas.
- ``# VERIFICAR`` = no confirmado contra el HTML real. Las confirmadas con docs/html_snippets.md
  (captura 2026-11-26, aviso "Analista mesa de ayuda") no llevan marca.
"""

# ---------------------------------------------------------------------------
# LISTADO de búsqueda
# ---------------------------------------------------------------------------

# Tarjeta de cada aviso dentro del listado. (confirmado)
JOB_CARD = "article.box_offer[data-id]"

# Atributo con el id del aviso en la tarjeta (32 hex). (confirmado)
JOB_CARD_ID_ATTR = "data-id"

# Link al aviso dentro de la tarjeta; href relativo "/ofertas-de-trabajo/...-<ID>#lc=...". (confirmado)
JOB_CARD_LINK = "h2 a.js-o-link"

# Título visible del aviso dentro de la tarjeta. (confirmado: mismo elemento que el link)
JOB_CARD_TITLE = "h2 a.js-o-link"

# Ubicación y modalidad de la tarjeta: "Retiro, Capital Federal" (p) y "Remoto" (div con icono de casa).
# Se unen y se pasan a filters.evaluate_job. (confirmado en docs/html_snippets.md)
JOB_CARD_LOCATION = "p.fs16.fc_base.mt5, div.fs13.mt15"

# Etiqueta "Postulado" de la tarjeta; sin la clase ``hide`` => ya postulado. (confirmado)
JOB_CARD_APPLIED_TAG = "span.tag.postulated:not(.hide)"

# Botón "Siguiente" de la paginación: es un span, no un link. Su destino está en ``data-path``. (confirmado)
PAGINATION_NEXT = "span.buildLink[title='Siguiente'][data-path]"

# ---------------------------------------------------------------------------
# AVISO (panel de detalle + acciones)
# ---------------------------------------------------------------------------

# Panel de detalle del aviso: se abre a la derecha del listado al hacer clic en la tarjeta, sin
# navegar (la URL solo cambia el fragmento "#<id>"). Lleva ``data-id`` = id del aviso. (confirmado)
JOB_DETAIL = "[data-offers-grid-detail-container]"

# Texto del aviso del que se leen filtros y reglas de CV. Se usa el texto COMPLETO del panel de detalle
# (incluye botones y textos de la UI). NO confirmado: docs/html_snippets.md (34 bloques) no capturó el
# contenedor de la descripción. Cambiar por el selector exacto cuando se capture el HTML.
JOB_DESCRIPTION = "[data-offers-grid-detail-container]"  # VERIFICAR: contenedor de la descripción sin capturar

# Botón "Postularme". Su span exterior sin ``hide`` con ``offer-detail-not-applied`` => postulable. (confirmado)
# Es igual en avisos con y sin cuestionario (mismo ``/candidate/apply/?oi=``): en los que no tienen, el clic
# POSTULA en el acto con el CV por defecto de la cuenta. Por eso --dry-run no lo clica (5.2b).
APPLY_BUTTON = "span[data-apply-link][offer-detail-not-applied]:not(.hide)"

# Marcador de aviso ya postulado: span "Postulado" con ``offer-detail-applied``. (confirmado)
APPLIED_MARKER = "[offer-detail-applied]"

# Textos de "ya postulado". Se buscan antes de clicar "Postularme" (si APPLIED_MARKER no está) y también
# DESPUÉS del clic: a un aviso ya postulado el sitio responde en la caja de postulación con
# "Ya te postulaste a esta oferta" (logs/fallos, 2026-11-26). "Ya aplicaste a esta oferta" es el aviso del
# panel de detalle. "Postulado" a secas NO va: aparece en otras partes del listado. (confirmados)
ALREADY_APPLIED_TEXTS = (
    "Ya te postulaste",
    "Ya aplicaste",
)

# ---------------------------------------------------------------------------
# FORMULARIO de preguntas (flujo "kq": una pregunta por paso dentro de box_answer)
# ---------------------------------------------------------------------------

# Caja que contiene el cuestionario de la postulación. Tras clicar "Postularme" aparece esta caja, o
# directamente la caja de confirmación si el aviso no tiene cuestionario (el clic ya postuló). (confirmado)
KQ_BOX = "div.box_answer[box-answer]"

# Paso vigente del cuestionario: una pregunta a la vez. Sirve para preguntas de opción única
# (``field_radio_box``, ``data-kq-radio``) y de texto (``field_textarea``). Los pasos aún no
# llegados llevan ``hide``; un paso ya respondido conserva ``show`` pero recibe ``data-kq-response``
# y su grupo de opciones se oculta (logs/fallos, 2026-11-26). ``:visible`` porque el formulario
# aparece duplicado en el DOM. (confirmado para opción única; VERIFICAR en pasos de texto)
KQ_CURRENT_STEP = "div[data-kq-user-step].show:not(.hide):not([data-kq-response]):visible"

# Texto de la pregunta dentro del paso actual (atributo; el texto visible a veces está vacío). (confirmado)
KQ_QUESTION_LABEL = "label[data-kq-question-text]"

# Campo de respuesta abierta. Vive FUERA del paso (en ``div.box_send[show-question]``) y queda
# ``disabled`` mientras el paso actual es de opción única. Comprobar ``is_enabled`` antes de usarlo. (confirmado)
KQ_ANSWER_TEXTAREA = "textarea#inputText"

# Flecha de envío de la respuesta de texto; aparece con la clase ``send`` después de escribir.
# No existe en los pasos de opción única. (confirmado)
KQ_SEND_ARROW = "span.icon.i_arrow_up.send"

# Opciones de un paso de opción única: ``div.field_radio_box[data-kq-radio="true"]`` > ``div.group`` >
# ``label.radio`` (clic) con ``span.label_box`` como texto visible. (confirmado en logs/fallos, 2026-11-26;
# elegir la opción hace avanzar el paso)
KQ_RADIO_OPTION = "input[type='radio']"
KQ_RADIO_LABEL = "div.group label.radio"
KQ_RADIO_TEXT = "span.label_box"

# Botón "Usar respuesta" de la caja "Respuesta generada con IA basada en tu perfil" (``div.box_border``
# con ``data-kq-answer-ia``). Aparece también en pasos de opción única: solo se usa en preguntas de texto.
# ``:visible`` porque el DOM trae copias ocultas. (confirmado en el volcado; VERIFICAR que llene el campo)
KQ_SUGGESTED_BUTTON = "button[add-suggested-response]:visible"

# Select: no apareció en ningún aviso capturado todavía.
KQ_SELECT_FIELD = "select"  # VERIFICAR

# Botón final "Enviar mi CV" dentro de ``show-btn-apply``; aparece cuando no quedan preguntas. (confirmado)
KQ_SUBMIT_BUTTON = "div[show-btn-apply] a[data-apply-ac-kq]"

# "Volver al detalle": sale del cuestionario sin enviar y deja el panel del aviso. (confirmado)
KQ_BACK_BUTTON = "a[back-show-detail-container-click]"

# ---------------------------------------------------------------------------
# CV precargado (selector de CV)
# ---------------------------------------------------------------------------
# Toda la lista vive en la caja de confirmación, DESPUÉS de postular (tanto en avisos sin cuestionario como
# tras "Enviar mi CV"): ``div.popup.hide[box-cv]`` con un radio por CV, oculta hasta pulsar CV_OPEN_BUTTON.
# Antes de postular no hay selector de CV. (confirmado en logs/fallos y docs/html_snippets.md, 2026-11-26)

# Botón que abre la lista de CVs; muestra el CV adjunto en ``CV_CURRENT_TEXT``. Visible solo en la caja de
# confirmación, por eso también sirve para detectarla. (confirmado)
CV_OPEN_BUTTON = "span[open-box-cv][attach-cv-button]"

# Texto con el nombre del CV adjunto dentro de ``CV_OPEN_BUTTON`` (p. ej. "Nombre_Apellido_CV_HelpDesk.pdf",
# el CV por defecto de la cuenta, en una postulación recién enviada). (confirmado)
CV_CURRENT_TEXT = "[attach-cv-button-text]"

# Opción de radio por CV. ``data-val-fname`` = etiqueta exacta del CV (también existe la opción
# "No adjuntar Currículum"). El input está en el DOM aunque la lista esté cerrada. (confirmado)
CV_RADIO = "input[type='radio'][name='hdv'][data-val-fname]"

# Elemento clicable de una opción de CV, relativo a su ``CV_RADIO``: el ``label.radio`` que lo envuelve.
# (confirmado: el clic manual se hizo sobre ``span.label_box`` dentro de ese label)
CV_RADIO_LABEL = "xpath=ancestor::label[1]"

# Botón "Actualizar" que guarda el CV elegido en la postulación. (confirmado)
CV_CONFIRM_BUTTON = "a[attach-cv]"

# Cierra la lista de CVs sin cambios. (confirmado)
CV_CLOSE_BUTTON = "a[hide-box-cv]"

# Aviso del sitio tras "Actualizar" (``window.apply.alertMessageOK`` en el script de la caja). Respaldo de la
# confirmación del cambio de CV: la principal es que ``CV_CURRENT_TEXT`` pase a mostrar el CV elegido.
CV_UPDATED_TEXTS = ("Cambios guardados correctamente",)  # VERIFICAR: solo visto en el script, no en pantalla

# ---------------------------------------------------------------------------
# CONFIRMACIÓN
# ---------------------------------------------------------------------------

# Textos de la caja de confirmación de una postulación enviada. Ninguno puede ser parte de
# ALREADY_APPLIED_TEXTS: "Te postulaste" a secas NO va porque también matchea "Ya te postulaste a esta oferta".
SUCCESS_MESSAGE_TEXTS = (
    "¡Te postulaste correctamente!",  # título de la caja (confirmado en logs/fallos, aviso sin cuestionario)
    "Hemos adjuntado tu Currículum a la postulación",  # título de la lista de CVs; visible solo si está abierta (confirmado)
    "Tu postulación fue enviada",  # VERIFICAR
)

# ---------------------------------------------------------------------------
# SESIÓN
# ---------------------------------------------------------------------------

# Patrón (regex) de la URL a la que redirige el sitio cuando no hay sesión.
LOGIN_URL_PATTERN = r"/login|/iniciar-sesion|/ingresar"  # VERIFICAR

# Página que abre --login para que el usuario inicie sesión a mano. Debe matchear LOGIN_URL_PATTERN.
LOGIN_PAGE_URL = "https://ar.computrabajo.com/login"  # VERIFICAR

# Input de contraseña visible => formulario de login en pantalla.
# (No usar links "Iniciar sesión" del header: aparecen también con sesión activa.)
LOGIN_PASSWORD_INPUT = "input[type='password']"  # VERIFICAR

# Textos que aparecen cuando la sesión expiró.
SESSION_EXPIRED_TEXTS = (
    "Tu sesión expiró",
    "sesión expirada",
    "Iniciá sesión nuevamente",
)  # VERIFICAR

# Elemento que solo aparece con sesión iniciada (ej. menú de cuenta).
LOGGED_IN_MARKER = "a:has-text('Mi perfil'), a[href*='/perfil']"  # VERIFICAR

# ---------------------------------------------------------------------------
# CAPTCHA
# ---------------------------------------------------------------------------

# iframes de reCAPTCHA / hCaptcha.
CAPTCHA_IFRAME = "iframe[src*='recaptcha'], iframe[src*='hcaptcha']"  # VERIFICAR

# Patrón (regex) de URL de challenge de captcha.
CAPTCHA_URL_PATTERN = r"captcha|challenge"  # VERIFICAR
