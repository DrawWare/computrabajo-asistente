"""Postulación a un aviso: máquina de estados (tareas 4.2 y 5.2b).

Estados (GUIA.md, "Formulario a medias"). El selector de CV recién aparece en la caja de confirmación,
DESPUÉS de postular (bloque 5.2), así que el CV se elige al final:
    FORM_DETECTED → QUESTIONS_ANSWERED → SUBMIT_CLICKED → SUCCESS_CONFIRMED → CV_SELECTED

- ``--dry-run``: NO clica "Postularme". En avisos sin cuestionario ese clic ya envía la postulación y el
  botón es igual en los dos casos, así que no hay simulacro seguro. Devuelve ``dry_run`` con el CV y la
  pretensión que se usarían.
- Corrida real, según lo que aparece tras clicar "Postularme":
  - cuestionario → se responde, se pulsa "Enviar mi CV" y se espera la caja de confirmación;
  - caja de confirmación ("¡Te postulaste correctamente!") → aviso sin cuestionario: ya quedó ``postulado``
    (cuenta en el tope diario);
  - "Ya te postulaste a esta oferta" → ``ya_postulado``.
  Tras postular, ``attach_cv`` pone el CV elegido por cv_router desde esa misma caja. Si no puede, la
  postulación cuenta igual: ``cv_used`` = CV que muestra la caja y el motivo va a ``error``.
- Pregunta sin respuesta segura → ``pendiente`` con motivo ``pregunta_sin_regla``; no se envía.
- Fallo antes de postular → ``error``; nunca se reintenta el mismo aviso en la corrida.

Todo ocurre en el listado: el aviso se abre con ``search.open_card`` (clic en la tarjeta, panel
derecho), ``read_description`` lee el texto del panel y ``run_apply`` postula desde ese mismo panel.
No hay navegación a la URL del aviso.

La lógica pura (``questions.resolve_answer``, ``salary_summary``) se prueba directo; el flujo de página,
sobre la página falsa de tests/fake_page.py. Los selectores sin confirmar están marcados en page_selectors.py.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Mapping, NamedTuple, Sequence, TypeVar

from playwright.sync_api import Locator, Page, TimeoutError as PlaywrightTimeoutError

import page_selectors as sel
from browser import (
    CaptchaTimeoutError,
    PageLoadTimeoutError,
    wait_captcha_if_present,
)
from cv_router import labels_equal
from dedupe import KIND_OTHER, KIND_RADIO, KIND_SELECT, KIND_TEXT_AI_EMPTY, KIND_TEXT_NO_AI
from questions import DEFAULT_HOME, HomeLocation, format_ars, resolve_answer, salary_answer  # noqa: F401 (salary_answer: API de apply)
from search import JobCard, css_attr

logger = logging.getLogger(__name__)

CV_PRINCIPAL = "PRINCIPAL_DEL_PERFIL"  # cv_used cuando la caja de confirmación no deja leer el CV adjunto
MAX_QUESTION_STEPS = 30
POLL_MS = 300
CV_CHANGE_TIMEOUT_MS = 10_000  # tope de cada espera del cambio de CV (abrir la lista, confirmar el cambio)

T = TypeVar("T")

# Diagnóstico local de fallos técnicos (gitignored: el HTML contiene datos del candidato).
FAILURE_DIR = Path(__file__).resolve().parent / "logs" / "fallos"
_PANEL_DUMP_JS = """() => [...document.querySelectorAll(
    '[data-offers-grid-detail-container], [data-offers-grid-apply-container], div.box_answer[box-answer]'
)].map(e => `<!-- data-id=${e.getAttribute('data-id') || ''} | visible=${e.getClientRects().length > 0} -->\\n${e.outerHTML}`)
  .join('\\n\\n')"""


class ApplyState(Enum):
    FORM_DETECTED = "form_detected"
    QUESTIONS_ANSWERED = "questions_answered"
    SUBMIT_CLICKED = "submit_clicked"
    SUCCESS_CONFIRMED = "success_confirmed"
    CV_SELECTED = "cv_selected"


@dataclass
class ApplyResult:
    status: str  # postulado | ya_postulado | sin_boton | descartado | pendiente | dry_run | error
    cv_used: str | None = None  # postulado: CV que quedó adjunto; dry_run: CV que se usaría
    error: str | None = None  # error: qué falló; postulado: por qué no se pudo poner el CV elegido
    motivo: str | None = None  # pendiente: pregunta_sin_regla; descartado: sin_cv
    detalle: str = ""
    state: ApplyState | None = None
    pending_questions: list[str] = field(default_factory=list)
    salary: Mapping[str, int] | None = None  # dry_run: pretensión del rol que se usaría
    pending_kind: str = ""  # pendiente: tipo de campo de la pregunta (dedupe.KIND_*)
    pending_options: tuple[str, ...] = ()  # pendiente: opciones del radio/select de la pregunta


# ---------------------------------------------------------------------------
# Lógica pura (resolve_answer y salary_answer viven en questions.py: también los usa pending_report.py)
# ---------------------------------------------------------------------------


def salary_summary(salary: Mapping[str, int] | None) -> str:
    """Pretensión que se usaría, para el log del dry-run: "pretensión $1.150.000 netos / $1.400.000 brutos"."""
    if not salary:
        return "pretensión: sin monto del rol (se usaría responses.json)"
    return f"pretensión {format_ars(int(salary['neto']))} netos / {format_ars(int(salary['bruto']))} brutos"


class QuestionsOutcome(NamedTuple):
    """Resultado de ``_answer_questions``. ok=False con ``question`` => pregunta sin respuesta (pendiente)."""

    ok: bool
    question: str | None = None
    detail: str = ""
    kind: str = ""  # dedupe.KIND_*: tipo de campo de la pregunta pendiente (columna "tipo" de pendientes.csv)
    options: tuple[str, ...] = ()  # opciones del radio/select de la pregunta pendiente


# ---------------------------------------------------------------------------
# Helpers de página
# ---------------------------------------------------------------------------


def _visible(locator, timeout_ms: float) -> bool:
    try:
        locator.first.wait_for(state="visible", timeout=timeout_ms)
        return True
    except PlaywrightTimeoutError:
        return False


def _is_visible_now(locator) -> bool:
    return locator.count() > 0 and locator.first.is_visible()


def _first_visible(locator) -> Locator | None:
    """Primer elemento visible del locator, o None. El sitio deja copias ocultas en el DOM."""
    for index in range(locator.count()):
        item = locator.nth(index)
        if item.is_visible():
            return item
    return None


def _any_visible(locator) -> bool:
    return _first_visible(locator) is not None


def _any_text_visible(page: Page, texts: Sequence[str]) -> bool:
    return any(_any_visible(page.get_by_text(text, exact=False)) for text in texts)


def _poll(page: Page, check: Callable[[], T], timeout_ms: float) -> T:
    """Evalúa ``check`` cada POLL_MS hasta que devuelva algo verdadero o venza el plazo; devuelve el último valor."""
    deadline = time.monotonic() + timeout_ms / 1000
    while True:
        value = check()
        if value or time.monotonic() >= deadline:
            return value
        page.wait_for_timeout(POLL_MS)


def _dump_failure(page: Page, job: JobCard, reason: str) -> None:
    """Guarda HTML de los paneles (con visibilidad) y una captura, para diagnosticar un fallo técnico."""
    try:
        FAILURE_DIR.mkdir(parents=True, exist_ok=True)
        base = FAILURE_DIR / f"{time.strftime('%Y%m%d_%H%M%S')}_{job.job_id}"
        base.with_suffix(".html").write_text(page.evaluate(_PANEL_DUMP_JS), encoding="utf-8")
        page.screenshot(path=str(base.with_suffix(".png")))
        logger.warning("Aviso %s (%s): diagnóstico en %s", job.job_id, reason, base)
    except Exception as exc:  # el diagnóstico nunca debe interrumpir la corrida
        logger.warning("Aviso %s: no se pudo guardar el diagnóstico: %s", job.job_id, exc)


def read_description(page: Page, job_id: str, timeout_ms: float) -> str | None:
    """Texto del aviso abierto en su panel de detalle, o None si el panel no apareció.

    Espera el panel con el ``data-id`` del aviso: un panel de otro aviso puede seguir en el DOM.
    Ver ``page_selectors.JOB_DESCRIPTION``: hoy es el panel completo, no el contenedor de la descripción.
    """
    panel = page.locator(f"{sel.JOB_DESCRIPTION}[data-id={css_attr(job_id)}]").first
    if not _visible(panel, timeout_ms):
        return None
    return " ".join(panel.inner_text().split())


def detect_button_state(page: Page) -> str:
    """``already_applied`` | ``can_apply`` | ``no_button``."""
    if _is_visible_now(page.locator(sel.APPLIED_MARKER)):
        return "already_applied"
    for text in sel.ALREADY_APPLIED_TEXTS:
        if _is_visible_now(page.get_by_text(text, exact=False)):
            return "already_applied"
    if _is_visible_now(page.locator(sel.APPLY_BUTTON)):
        return "can_apply"
    return "no_button"


# --- Lo que aparece tras clicar "Postularme" -----------------------------------------


def _confirmation_visible(page: Page) -> bool:
    """Caja de confirmación a la vista: el botón del CV adjunto o "¡Te postulaste correctamente!"."""
    return _any_visible(page.locator(sel.CV_OPEN_BUTTON)) or _any_text_visible(page, sel.SUCCESS_MESSAGE_TEXTS)


def _after_apply_click(page: Page) -> str | None:
    """Qué muestra el panel tras clicar "Postularme": cuestionario | confirmacion | ya_postulado, o None (nada aún)."""
    if _any_visible(page.locator(sel.KQ_BOX)):
        return "cuestionario"
    if _confirmation_visible(page):
        return "confirmacion"
    if _any_text_visible(page, sel.ALREADY_APPLIED_TEXTS):
        return "ya_postulado"
    return None


def _apply_panel_busy(page: Page) -> str | None:
    """Motivo para NO clicar "Postularme": ya hay un cuestionario o una caja de confirmación a la vista.

    Serían de otro aviso, y con ellos en pantalla no se puede saber qué produjo el clic: se contaría como
    postulado un aviso al que no se postuló, o se cambiaría el CV de otra postulación.
    """
    if _any_visible(page.locator(sel.KQ_BOX)):
        return "ya había un cuestionario a la vista antes de clicar 'Postularme'"
    if _confirmation_visible(page):
        return "ya había una caja de confirmación a la vista antes de clicar 'Postularme'"
    return None


def _wait_success(page: Page, timeout_ms: float) -> bool:
    """Tras "Enviar mi CV": espera la caja de confirmación (o la marca "Postulado" del panel)."""
    return bool(
        _poll(page, lambda: _confirmation_visible(page) or _is_visible_now(page.locator(sel.APPLIED_MARKER)), timeout_ms)
    )


# --- CV en la caja de confirmación ---------------------------------------------------


def current_cv_label(page: Page) -> str | None:
    """CV adjunto que muestra la caja de confirmación, o None si la caja no está a la vista."""
    text = _first_visible(page.locator(sel.CV_CURRENT_TEXT))
    if text is None:
        return None
    return " ".join(text.inner_text().split()) or None


def _cv_option(page: Page, label: str) -> Locator | None:
    """Elemento clicable y visible del CV ``label`` en la lista de la confirmación, o None."""
    radios = page.locator(sel.CV_RADIO)
    for index in range(radios.count()):
        radio = radios.nth(index)
        if labels_equal(radio.get_attribute("data-val-fname"), label):
            option = radio.locator(sel.CV_RADIO_LABEL)
            if option.is_visible():
                return option
    return None


def select_cv_by_label(page: Page, label: str, timeout_ms: float = CV_CHANGE_TIMEOUT_MS) -> str | None:
    """Marca en la caja de confirmación el CV precargado con la etiqueta ``label`` y pulsa "Actualizar".

    La lista de CVs (``CV_RADIO``) solo existe en esa caja, después de postular, cerrada hasta pulsar
    ``CV_OPEN_BUTTON``. Compara etiquetas normalizadas (``labels_equal``): el sitio puede traer otra forma
    Unicode de la ñ. Devuelve None si llegó a pulsar "Actualizar", o el motivo por el que no pudo.
    """
    open_button = _first_visible(page.locator(sel.CV_OPEN_BUTTON))
    if open_button is None:
        return "la caja de confirmación no muestra el botón del CV adjunto"
    radios = page.locator(sel.CV_RADIO)
    if not any(labels_equal(radios.nth(i).get_attribute("data-val-fname"), label) for i in range(radios.count())):
        return f"la etiqueta {label!r} no está en la lista de CVs del sitio"

    option = _cv_option(page, label)
    if option is None:
        open_button.click()
        option = _poll(page, lambda: _cv_option(page, label), timeout_ms)
    if option is None:
        return "la lista de CVs no se abrió"
    option.click()

    update = _poll(page, lambda: _first_visible(page.locator(sel.CV_CONFIRM_BUTTON)), timeout_ms)
    if update is None:
        return "no apareció el botón 'Actualizar' de la lista de CVs"
    update.click()
    return None


def _cv_change_confirmed(page: Page, label: str) -> bool:
    return labels_equal(current_cv_label(page), label) or _any_text_visible(page, sel.CV_UPDATED_TEXTS)


def _close_cv_box(page: Page) -> None:
    """Cierra la lista de CVs si quedó abierta: su overlay taparía la tarjeta del aviso siguiente."""
    try:
        close = _first_visible(page.locator(sel.CV_CLOSE_BUTTON))
        if close is not None:
            close.click()
    except Exception as exc:  # cerrar es cortesía: nunca debe tapar el resultado de la postulación
        logger.warning("No se pudo cerrar la lista de CVs: %s", exc)


def _shown_cv(page: Page) -> str | None:
    try:
        return current_cv_label(page)
    except Exception:  # solo informativo: CV_PRINCIPAL si no se puede leer
        return None


def attach_cv(page: Page, job: JobCard, label: str, timeout_ms: float = CV_CHANGE_TIMEOUT_MS) -> tuple[str, str | None]:
    """Deja adjunto a la postulación recién enviada el CV ``label``, desde la caja de confirmación.

    Devuelve (cv_usado, problema). ``problema`` None => la caja muestra ``label`` como CV adjunto (o el sitio
    confirmó el cambio). Nunca lanza: la postulación ya se envió y tiene que quedar registrada. Si el cambio
    falla, ``cv_usado`` es el CV que muestra la caja (o CV_PRINCIPAL si no se puede leer).
    """
    problem: str | None
    try:
        if labels_equal(current_cv_label(page), label):
            return label, None  # ya era el CV adjunto (el "por defecto" de la cuenta)
        problem = select_cv_by_label(page, label, timeout_ms)
        if problem is None:
            if _poll(page, lambda: _cv_change_confirmed(page, label), timeout_ms):
                logger.info("CV adjunto cambiado a %s", label)
                return label, None
            problem = "tras 'Actualizar' la caja no muestra el CV elegido"
    except Exception as exc:  # la postulación ya se envió: registrarla pesa más que este fallo
        problem = " ".join(str(exc).split())[:300] or type(exc).__name__
    finally:
        _close_cv_box(page)

    logger.warning("Aviso %s: postulado, pero el CV no se pudo cambiar a %s: %s", job.job_id, label, problem)
    _dump_failure(page, job, "CV no cambiado")
    return _shown_cv(page) or CV_PRINCIPAL, problem


def _applied(page: Page, job: JobCard, cv_label: str, timeout_ms: float, note: str = "") -> ApplyResult:
    """La postulación ya se envió (cuenta en el tope diario): pone el CV elegido desde la confirmación."""
    cv_used, problem = attach_cv(page, job, cv_label, min(timeout_ms, CV_CHANGE_TIMEOUT_MS))
    return ApplyResult(
        "postulado",
        cv_used=cv_used,
        error=None if problem is None else f"CV no cambiado a {cv_label}: {problem}",
        detalle=note,
        state=ApplyState.CV_SELECTED if problem is None else ApplyState.SUCCESS_CONFIRMED,
    )


# --- Cuestionario --------------------------------------------------------------------


def _question_text(step) -> str:
    label = step.locator(sel.KQ_QUESTION_LABEL).first
    return (label.get_attribute("data-kq-question-text") or label.inner_text() or "").strip()


def _wait_next_step(page: Page, previous_question: str, timeout_ms: float) -> None:
    """Espera a que aparezca la pregunta siguiente o el botón final de envío."""
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if _is_visible_now(page.locator(sel.KQ_SUBMIT_BUTTON)):
            return
        step = page.locator(sel.KQ_CURRENT_STEP)
        if _is_visible_now(step) and _question_text(step.first) != previous_question:
            return
        page.wait_for_timeout(POLL_MS)


def _answer_questions(
    page: Page,
    responses: Sequence[dict],
    timeout_ms: float,
    salary: Mapping[str, int] | None = None,
    home: HomeLocation | None = None,
) -> QuestionsOutcome:
    """Responde el cuestionario paso a paso.

    Devuelve ``QuestionsOutcome``. ok=False => no se envía; si además trae ``question``, es la pregunta
    sin respuesta segura, con su tipo de campo y sus opciones (para pendientes.csv).
    ``home`` = lugar de residencia para preguntas de ubicación (None => DEFAULT_HOME, Córdoba).
    """
    home = home if home is not None else DEFAULT_HOME
    for _ in range(MAX_QUESTION_STEPS):
        if _is_visible_now(page.locator(sel.KQ_SUBMIT_BUTTON)):
            return QuestionsOutcome(True)

        step_locator = page.locator(sel.KQ_CURRENT_STEP)
        if not _visible(step_locator, timeout_ms):
            return QuestionsOutcome(False, None, "no apareció el siguiente paso ni el botón de envío")

        step = step_locator.first
        question = _question_text(step)
        radios = step.locator(sel.KQ_RADIO_OPTION)
        select = step.locator(sel.KQ_SELECT_FIELD)
        # El textarea vive fuera del paso (box_send); solo se usa si está habilitado.
        textarea = page.locator(sel.KQ_ANSWER_TEXTAREA)
        text_enabled = textarea.count() > 0 and textarea.first.is_enabled()

        if radios.count() > 0:
            # Opción única: elegir la opción hace avanzar el cuestionario; no hay flecha de envío.
            # Texto de cada opción = span.label_box; click = label.radio, en el mismo orden.
            options = [t.strip() for t in step.locator(sel.KQ_RADIO_TEXT).all_inner_texts()]
            if not options or not all(options):
                return QuestionsOutcome(
                    False, question, "el paso de opción única no tiene opciones visibles", KIND_RADIO, tuple(options)
                )
            answer = resolve_answer(question, responses, options, salary=salary, home=home)
            if answer is None:
                return QuestionsOutcome(False, question, "sin opción segura en los radios", KIND_RADIO, tuple(options))
            step.locator(sel.KQ_RADIO_LABEL).nth(options.index(answer)).click()
            logger.info("Pregunta respondida (opción): %s -> %s", question, answer)
            _wait_next_step(page, question, timeout_ms)
            continue

        if select.count() > 0:
            options = [o.strip() for o in select.first.locator("option").all_inner_texts() if o.strip()]
            if not options:
                return QuestionsOutcome(False, question, "el select no tiene opciones", KIND_SELECT)
            answer = resolve_answer(question, responses, options, salary=salary, home=home)
            if answer is None:
                return QuestionsOutcome(False, question, "sin opción segura en el select", KIND_SELECT, tuple(options))
            select.first.select_option(label=answer)
            kind = "lista"
        elif text_enabled:
            answer = resolve_answer(question, responses, salary=salary, home=home)
            kind = "texto"
            if answer is not None:
                textarea.first.fill(answer)
            else:
                had_ai_button = _is_visible_now(page.locator(sel.KQ_SUGGESTED_BUTTON))
                if _use_suggested_response(page, textarea, timeout_ms):
                    answer = textarea.first.input_value().strip()
                    kind = "texto sugerido por la IA"
                else:
                    return QuestionsOutcome(
                        False,
                        question,
                        "sin regla en responses.json ni respuesta sugerida",
                        KIND_TEXT_AI_EMPTY if had_ai_button else KIND_TEXT_NO_AI,
                    )
        else:
            return QuestionsOutcome(False, question, "tipo de campo no soportado", KIND_OTHER)

        # Respuesta de texto/select: la flecha de envío aparece con la clase "send" después de escribir/elegir.
        arrow = page.locator(sel.KQ_SEND_ARROW)
        if not _visible(arrow, timeout_ms):
            return QuestionsOutcome(False, question, "no apareció la flecha de envío de la respuesta")
        arrow.first.click()
        logger.info("Pregunta respondida (%s): %s -> %s", kind, question, answer)
        _wait_next_step(page, question, timeout_ms)

    return QuestionsOutcome(False, None, "se superó el máximo de pasos del cuestionario")


def _use_suggested_response(page: Page, textarea, timeout_ms: float) -> bool:
    """Pulsa "Usar respuesta" (sugerencia de la IA del perfil) si está visible y espera a que llene el campo.

    True => el campo quedó con texto y el caller lo envía con la flecha como cualquier respuesta.
    False => no hay botón, o el campo no se llenó a tiempo.
    """
    button = page.locator(sel.KQ_SUGGESTED_BUTTON)
    if not _is_visible_now(button):
        return False
    button.first.click()
    deadline = time.monotonic() + timeout_ms / 1000
    while time.monotonic() < deadline:
        if textarea.first.input_value().strip():
            return True
        page.wait_for_timeout(POLL_MS)
    return False


# ---------------------------------------------------------------------------
# Punto de entrada
# ---------------------------------------------------------------------------


def run_apply(
    page: Page,
    job: JobCard,
    cv_label: str | None,
    responses: Sequence[dict],
    *,
    dry_run: bool,
    page_timeout: float,
    captcha_timeout: float,
    salary: Mapping[str, int] | None = None,
    home: HomeLocation | None = None,
) -> ApplyResult:
    """Postula a ``job`` desde su panel ya abierto (``search.open_card``). Devuelve ApplyResult.

    No navega: el botón "Postularme", el cuestionario y la caja de confirmación están en el panel del listado.
    ``cv_label`` es la etiqueta ya elegida por cv_router (None => descartado, motivo sin_cv).
    ``salary`` = {"neto", "bruto"} del rol (cv_router.salary_for); None => valor de responses.json.
    """
    timeout_ms = page_timeout * 1000
    state: ApplyState | None = None
    try:
        wait_captcha_if_present(page, captcha_timeout)

        button = detect_button_state(page)
        if button == "already_applied":
            return ApplyResult("ya_postulado")
        if button == "no_button":
            return ApplyResult("sin_boton")
        if cv_label is None:
            # Decisión 2026-11-26: sin regla de CV => descartado (pendientes.csv queda solo para preguntas nuevas).
            return ApplyResult("descartado", motivo="sin_cv", detalle="ninguna regla de CV matchea el aviso")

        if dry_run:
            # 5.2b: el simulacro termina acá. En avisos sin cuestionario, clicar "Postularme" ya postula.
            return ApplyResult("dry_run", cv_used=cv_label, salary=salary, detalle=salary_summary(salary))

        busy = _apply_panel_busy(page)
        if busy is not None:
            _dump_failure(page, job, busy)
            return ApplyResult("error", error=f"{busy}; no se clicó")

        page.locator(sel.APPLY_BUTTON).first.click()
        outcome = _poll(page, lambda: _after_apply_click(page), timeout_ms)
        if outcome is None:
            _dump_failure(page, job, "sin cuestionario ni confirmación")
            return ApplyResult("error", error="tras clicar 'Postularme' no apareció el cuestionario ni la confirmación")
        if outcome == "ya_postulado":
            return ApplyResult("ya_postulado", detalle="el sitio respondió 'Ya te postulaste' al clicar 'Postularme'")
        if outcome == "confirmacion":
            # Aviso sin cuestionario: el clic ya envió la postulación, con el CV por defecto de la cuenta.
            logger.info("Aviso %s sin cuestionario: quedó postulado al clicar 'Postularme'", job.job_id)
            return _applied(page, job, cv_label, timeout_ms, note="sin cuestionario")
        state = ApplyState.FORM_DETECTED

        answered = _answer_questions(page, responses, timeout_ms, salary, home)
        if not answered.ok:
            if answered.question is None:
                _dump_failure(page, job, answered.detail)
                return ApplyResult("error", error=answered.detail, state=state)
            return ApplyResult(
                "pendiente",
                motivo="pregunta_sin_regla",
                detalle=f"{answered.question} ({answered.detail})",
                state=state,
                pending_questions=[answered.question],
                pending_kind=answered.kind,
                pending_options=answered.options,
            )
        state = ApplyState.QUESTIONS_ANSWERED

        page.locator(sel.KQ_SUBMIT_BUTTON).first.click()
        state = ApplyState.SUBMIT_CLICKED

        if not _wait_success(page, timeout_ms):
            _dump_failure(page, job, "no se confirmó el envío")
            return ApplyResult("error", error="no se confirmó el envío", state=state)
        return _applied(page, job, cv_label, timeout_ms)

    except (CaptchaTimeoutError, PageLoadTimeoutError, PlaywrightTimeoutError) as exc:
        # El mensaje de Playwright trae el locator que falló en el "Call log": se conserva en una línea.
        message = " ".join(str(exc).split())[:500]
        logger.error("Aviso %s: %s", job.job_id, message)
        if isinstance(exc, PlaywrightTimeoutError):
            _dump_failure(page, job, "timeout")
        return ApplyResult("error", error=message, state=state)
