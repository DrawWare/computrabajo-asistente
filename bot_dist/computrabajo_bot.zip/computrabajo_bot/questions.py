"""Cruce pregunta del formulario → respuesta, por regex.

- match_answer: busca en responses.json la primera regla cuyo patrón matchea la pregunta.
- pick_option: mapea una respuesta de texto a una opción de select/radio.
- resolve_answer: respuesta final para una pregunta (texto o una de las opciones), o None.

Módulo puro: sin navegador. Si nada matchea, devuelve None (el caller marca pendiente).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Mapping, Sequence

from filters import is_excluded, normalize

# {"pattern": "<regex>", "answer": "<texto libre>", "option": "<opción de radio/select>" (opcional)}
ResponseRule = Mapping[str, str]

# Dato que el usuario todavía tiene que completar en responses.json ("[COMPLETAR_TELEFONO]"). Una regla con un
# placeholder en "answer" u "option" no se usa nunca: el bot no envía ese texto a una empresa.
PLACEHOLDER_RE = re.compile(r"\[COMPLETAR[^\]]*\]", re.IGNORECASE)

_STOPWORDS = frozenset(
    {"con", "sin", "los", "las", "del", "por", "para", "que", "tus", "sus", "muy", "una", "uno", "the", "and"}
)

# Residencia de sí/no (regla dinámica, solo para radio/select). Términos ya normalizados (sin tildes).
_RESIDENCE_TRIGGERS = ("residis", "vivis", "radicado", "radicada")
# "¿Residís fuera de Argentina?": nombra el lugar pero pregunta lo contrario. No se adivina.
_RESIDENCE_NEGATIONS = ("fuera", "afuera", "exterior", "extranjero", "lejos")
_HOME_PLACES = ("cordoba",)
_HOME_COUNTRY = ("argentina",)
# Otros países. Si la pregunta nombra uno => "No" (si también nombra Argentina, es ambigua).
_OTHER_COUNTRIES = (
    "uruguay", "chile", "paraguay", "bolivia", "brasil", "peru", "colombia", "venezuela", "ecuador",
    "mexico", "costa rica", "panama", "guatemala", "republica dominicana", "espana", "estados unidos",
    "eeuu", "ee.uu.",
)
# Otras ciudades y provincias. Si la pregunta nombra una y no Córdoba => "No".
_OTHER_PLACES = (
    "santa fe", "buenos aires", "caba", "capital federal", "ciudad autonoma", "gba", "amba",
    "conurbano", "gran buenos aires", "la plata", "mar del plata", "bahia blanca", "quilmes", "lanus",
    "avellaneda", "moron", "tigre", "san isidro", "vicente lopez", "rosario", "rafaela", "reconquista",
    "mendoza", "tucuman", "salta", "jujuy", "neuquen", "rio negro", "chubut", "santa cruz",
    "tierra del fuego", "la pampa", "entre rios", "parana", "corrientes", "misiones", "posadas",
    "chaco", "resistencia", "formosa", "santiago del estero", "la rioja", "catamarca", "san juan",
    "san luis", "rio cuarto", "villa maria", "san francisco", "carlos paz", "villa allende",
)
ALL_AR_PLACES = _OTHER_PLACES + ("cordoba",)


@dataclass(frozen=True)
class HomeLocation:
    """Lugar de residencia de la persona (6.2.1): ``home_places`` = sus términos; ``other_places`` = el resto."""

    home_places: tuple[str, ...]
    other_places: tuple[str, ...]


DEFAULT_HOME = HomeLocation(_HOME_PLACES, _OTHER_PLACES)


def home_from_terms(home_terms: Sequence[str]) -> HomeLocation:
    """Arma el lugar de residencia desde ``location.home_terms``: otros lugares = los de ALL_AR_PLACES que no matchean."""
    home = tuple(home_terms)
    others = tuple(place for place in ALL_AR_PLACES if not is_excluded(place, None, home))
    return HomeLocation(home, others)


def _loose(text: str) -> str:
    """Normaliza y deja solo palabras separadas por un espacio (ignora puntuación)."""
    return " ".join(re.findall(r"[a-z0-9]+", normalize(text)))


def _significant_tokens(text: str) -> set[str]:
    return {t for t in _loose(text).split() if len(t) >= 3 and t not in _STOPWORDS}


def placeholders(rule: ResponseRule) -> list[str]:
    """Placeholders sin completar ("[COMPLETAR_TELEFONO]") en el answer o la option de la regla."""
    found = PLACEHOLDER_RE.findall(rule.get("answer") or "") + PLACEHOLDER_RE.findall(rule.get("option") or "")
    return list(dict.fromkeys(found))


def incomplete_rules(rules: Sequence[ResponseRule]) -> list[ResponseRule]:
    """Reglas que ``match_rule`` ignora porque tienen un placeholder sin completar."""
    return [rule for rule in rules if placeholders(rule)]


def match_rule(question_text: str, rules: Sequence[ResponseRule]) -> ResponseRule | None:
    """Primera regla (en orden) cuyo patrón matchea la pregunta, case-insensitive.

    Las reglas con un placeholder sin completar ("[COMPLETAR_...]") se saltean: es como si no existieran.
    """
    if not question_text:
        return None
    for rule in rules:
        if placeholders(rule):
            continue
        if re.search(rule["pattern"], question_text, re.IGNORECASE):
            return rule
    return None


def match_answer(question_text: str, rules: Sequence[ResponseRule]) -> str | None:
    """Texto de respuesta libre de la primera regla que matchea (ver ``match_rule``)."""
    rule = match_rule(question_text, rules)
    return None if rule is None else rule["answer"]


def residence_yes_no(question_text: str, home: HomeLocation = DEFAULT_HOME) -> str | None:
    """"Sí" / "No" para una pregunta de residencia de sí/no, o None si no aplica o no es seguro.

    - Solo si consulta residencia ("residís", "vivís", "radicado/a") y no por vivir "fuera de" un lugar.
    - Menciona el lugar de residencia (``home``, Córdoba por defecto) y ningún otro => "Sí" (Argentina no cuenta).
    - Menciona otra ciudad o provincia y no el lugar de residencia => "No", aunque diga Argentina.
    - Menciona otro país => "No", salvo que también nombre Argentina ("¿Argentina o Uruguay?": ambigua).
    - Menciona solo Argentina => "Sí".
    - Córdoba junto con otro lugar, o ningún lugar => None (pendiente: no se adivina).
    """
    if not question_text or not is_excluded(question_text, None, _RESIDENCE_TRIGGERS):
        return None
    if is_excluded(question_text, None, _RESIDENCE_NEGATIONS):
        return None
    in_home = is_excluded(question_text, None, home.home_places)
    in_argentina = is_excluded(question_text, None, _HOME_COUNTRY)
    other_place = is_excluded(question_text, None, home.other_places)
    other_country = is_excluded(question_text, None, _OTHER_COUNTRIES)
    if in_home:
        return None if (other_place or other_country) else "Sí"
    if other_place:
        return "No"
    if other_country:
        return None if in_argentina else "No"
    return "Sí" if in_argentina else None


# Pregunta abierta de ubicación con opciones por lugar ("¿Dónde vivís?" → CABA / GBA / Otra provincia).
_LOCATION_TRIGGERS = _RESIDENCE_TRIGGERS + (
    "donde vivis", "donde residis", "residencia", "domicilio", "localidad", "ubicacion", "ubicado", "ubicada",
)
# Opciones que cubren a Córdoba cuando no aparece por nombre, en orden de preferencia.
_INTERIOR_OPTIONS = (
    ("interior", "interior del pais"),
    ("otra provincia", "otras provincias"),
    ("resto del pais", "resto de argentina", "resto de las provincias"),
)


def location_option(question_text: str, options: Sequence[str], home: HomeLocation = DEFAULT_HOME) -> str | None:
    """Opción de un radio/select de ubicación por lugar, o None si no aplica o no es seguro.

    Solo para preguntas abiertas ("¿Dónde vivís?", "Zona de residencia") que no nombran un lugar: las que
    nombran uno ("¿Residís en Santa Fe?") son de sí/no y las resuelve ``residence_yes_no``.
    1) La opción que nombra Córdoba (si hay varias, la que dice "Capital"; si no se distingue, None).
    2) Si ninguna nombra Córdoba: "Interior (del país)"; después "Otra provincia"; después "Resto del país".
       Nunca una opción que nombre otro lugar ("Interior de Buenos Aires") o el exterior.
    """
    if not question_text or not options or not is_excluded(question_text, None, _LOCATION_TRIGGERS):
        return None
    if is_excluded(question_text, None, _RESIDENCE_NEGATIONS):
        return None
    if any(is_excluded(question_text, None, places) for places in (home.home_places, home.other_places, _OTHER_COUNTRIES)):
        return None

    cordoba = [o for o in options if is_excluded(o, None, home.home_places)]
    if len(cordoba) == 1:
        return cordoba[0]
    if cordoba:
        capital = [o for o in cordoba if is_excluded(o, None, ("capital",))]
        return capital[0] if len(capital) == 1 else None

    elsewhere = home.other_places + _OTHER_COUNTRIES + _RESIDENCE_NEGATIONS
    for terms in _INTERIOR_OPTIONS:
        found = [o for o in options if is_excluded(o, None, terms) and not is_excluded(o, None, elsewhere)]
        if len(found) == 1:
            return found[0]
        if found:
            return None
    return None


def pick_option(
    answer: str,
    options: Sequence[str],
    pattern: str | None = None,
) -> str | None:
    """Elige la opción de select/radio que corresponde a `answer`, o None si no hay una segura.

    Orden de criterios:
      1) igualdad normalizada ("Si" == "Sí").
      2) contención por palabras completas (la opción aparece en la respuesta o viceversa);
         si hay varias, gana la más larga.
      3) `pattern` (la regex de la regla que originó la respuesta) aplicada a las opciones.
      4) solapamiento de palabras significativas. Si hay empate entre opciones → None
         (no se adivina: mejor pendiente que una respuesta incorrecta).
    """
    if not answer or not options:
        return None
    wanted = _loose(answer)
    if not wanted:
        return None

    # 1) igualdad normalizada
    for option in options:
        if _loose(option) == wanted:
            return option

    # 2) contención por palabras completas
    padded_wanted = f" {wanted} "
    contained = []
    for option in options:
        candidate = _loose(option)
        if candidate and (f" {candidate} " in padded_wanted or padded_wanted in f" {candidate} "):
            contained.append(option)
    if contained:
        return max(contained, key=lambda o: len(_loose(o)))

    # 3) regex de la regla aplicada a las opciones
    if pattern:
        for option in options:
            if re.search(pattern, option, re.IGNORECASE):
                return option

    # 4) solapamiento de tokens significativos, sin empates
    wanted_tokens = _significant_tokens(answer)
    best: str | None = None
    best_score = 0
    ambiguous = False
    for option in options:
        score = len(wanted_tokens & _significant_tokens(option))
        if score > best_score:
            best, best_score, ambiguous = option, score, False
        elif score == best_score and score > 0:
            ambiguous = True
    if best is None or ambiguous:
        return None
    return best


# ---------------------------------------------------------------------------
# Sueldo / pretensión (calibración Nov-2026). Funciones puras; los montos vienen de cv_router.salary_for.
# ---------------------------------------------------------------------------

_SALARY_QUESTION_RE = re.compile(r"remuneraci|pretensi|salari|sueldo|expectativa salarial")
_BRUTO_WORD_RE = re.compile(r"\bbrut[oa]s?\b")
_NETO_WORD_RE = re.compile(r"\bnet[oa]s?\b|\ben mano\b")
_AMOUNT_RE = re.compile(r"\d{1,3}(?:[.,]\d{3})+|\d{4,}")  # 1.250.000 · 1,250,000 · 1250000
_UPPER_BOUND_RE = re.compile(r"\b(hasta|menos de|maximo|maximo de)\b")
_LOWER_BOUND_RE = re.compile(r"\b(mas de|desde|a partir de|minimo|minimo de)\b")


def is_salary_question(question_text: str) -> bool:
    """True si la pregunta pide sueldo / pretensión / remuneración."""
    return bool(question_text) and bool(_SALARY_QUESTION_RE.search(normalize(question_text)))


def salary_mode(question_text: str) -> str:
    """"bruto" si la pregunta dice bruto, "neto" si dice neto o en mano, "ambos" si no aclara (o dice las dos)."""
    text = normalize(question_text or "")
    bruto = bool(_BRUTO_WORD_RE.search(text))
    neto = bool(_NETO_WORD_RE.search(text))
    if bruto and not neto:
        return "bruto"
    if neto and not bruto:
        return "neto"
    return "ambos"


def format_ars(amount: int) -> str:
    """1250000 -> "$1.250.000"."""
    return f"${amount:,}".replace(",", ".")


def salary_target(question_text: str, salary: Mapping[str, int]) -> int:
    """Monto con el que se compara una opción de rango: bruto si lo piden, neto en el resto de los casos."""
    return int(salary["bruto"]) if salary_mode(question_text) == "bruto" else int(salary["neto"])


def salary_text(question_text: str, salary: Mapping[str, int]) -> str | None:
    """Respuesta de texto libre para una pregunta de sueldo, o None si no es de sueldo.

    - Pide bruto  => "$1.500.000 brutos"
    - Pide neto / en mano => "$1.250.000 netos"
    - No aclara   => "$1.250.000 netos ($1.500.000 brutos aprox.)"
    """
    if not is_salary_question(question_text):
        return None
    neto, bruto = int(salary["neto"]), int(salary["bruto"])
    mode = salary_mode(question_text)
    if mode == "bruto":
        return f"{format_ars(bruto)} brutos"
    if mode == "neto":
        return f"{format_ars(neto)} netos"
    return f"{format_ars(neto)} netos ({format_ars(bruto)} brutos aprox.)"


def parse_salary_range(option_text: str) -> tuple[float, float] | None:
    """Intervalo [min, max] de una opción de sueldo, o None si no es un rango numérico.

    Ejemplos: "Entre $1.000.000 y $1.300.000" -> (1000000, 1300000); "Más de $1.200.000" -> (1200000, inf);
    "Hasta $1.000.000" -> (0, 1000000).
    """
    text = normalize(option_text or "")
    amounts = [int(a.replace(".", "").replace(",", "")) for a in _AMOUNT_RE.findall(text)]
    if not amounts:
        return None
    if len(amounts) >= 2:
        low, high = sorted(amounts[:2])
        return (float(low), float(high))
    value = amounts[0]
    if _UPPER_BOUND_RE.search(text):
        return (0.0, float(value))
    if _LOWER_BOUND_RE.search(text):
        return (float(value), float("inf"))
    return None


def pick_salary_option(options: Sequence[str], target: int) -> str | None:
    """Opción de rango que contiene ``target``; si ninguna lo contiene, la más cercana.

    Rangos de borde compartido ("1.000.000–1.300.000" y "1.300.000–1.600.000") se resuelven con
    intervalo semiabierto [min, max). Si el resultado es ambiguo (empate de distancia) o ninguna
    opción es numérica, devuelve None: no se adivina.
    """
    parsed = [(opt, parse_salary_range(opt)) for opt in options]
    parsed = [(opt, rng) for opt, rng in parsed if rng is not None]
    if not parsed:
        return None

    inside = [opt for opt, (lo, hi) in parsed if lo <= target < hi]
    if not inside:  # el monto máximo de un rango cerrado ("hasta" o el último rango) también cuenta
        inside = [opt for opt, (lo, hi) in parsed if lo <= target <= hi]
    if len(inside) == 1:
        return inside[0]
    if len(inside) > 1:
        return None

    def _distance(rng: tuple[float, float]) -> float:
        lo, hi = rng
        return lo - target if target < lo else target - hi

    distances = sorted((_distance(rng), opt) for opt, rng in parsed)
    if len(distances) > 1 and distances[0][0] == distances[1][0]:
        return None
    return distances[0][1]


# ---------------------------------------------------------------------------
# Respuesta final para una pregunta del cuestionario (la usan apply.py y pending_report.py)
# ---------------------------------------------------------------------------


def salary_answer(question: str, salary: Mapping[str, int] | None) -> str | None:
    """Texto libre para preguntas de sueldo, con la pretensión del rol (ver ``salary_text``).

    "$1.500.000 brutos" si piden bruto; "$1.250.000 netos" si piden neto o en mano;
    "$1.250.000 netos ($1.500.000 brutos aprox.)" si no aclaran. None si no es de sueldo o no hay rol.
    """
    if not salary:
        return None
    return salary_text(question, salary)


def resolve_answer(
    question: str,
    responses: Sequence[ResponseRule],
    options: Sequence[str] | None = None,
    salary: Mapping[str, int] | None = None,
    *,
    home: HomeLocation = DEFAULT_HOME,
) -> str | None:
    """Respuesta para una pregunta. None => no hay respuesta segura (pendiente).

    Campos de texto (``options`` vacío): preguntas de salario usan la pretensión del rol (``salary``) si
    viene; si no, el ``answer`` de la regla de responses.json.

    Select/radio: se elige la opción que corresponde (``pick_option``) o None si no hay una segura.
    - Sueldo con rol: el rango que contiene la pretensión (``pick_salary_option``).
    - Residencia de sí/no (``residence_yes_no``): "Sí" si menciona Córdoba o Argentina, "No" si menciona
      otra provincia o país.
    - Ubicación con opciones por lugar (``location_option``): la opción de Córdoba, o "Interior" / "Otra
      provincia" si Córdoba no figura.
    - Resto: la regla usa su ``option`` si la tiene (p. ej. "Intermedio (B1)" para el radio de inglés) y,
      si no, su ``answer``.
    """
    if not options:
        from_salary = salary_answer(question, salary)
        if from_salary is not None:
            return from_salary
        rule = match_rule(question, responses)
        return None if rule is None else rule["answer"]

    if salary and is_salary_question(question):
        # Pregunta de sueldo con opciones: se elige el rango que contiene la pretensión (o el más cercano).
        return pick_salary_option(list(options), salary_target(question, salary))
    yes_no = residence_yes_no(question, home)
    if yes_no is not None:
        return pick_option(yes_no, list(options))
    place = location_option(question, list(options), home)
    if place is not None:
        return place
    rule = match_rule(question, responses)
    if rule is None:
        return None
    return pick_option(rule.get("option") or rule["answer"], list(options))
