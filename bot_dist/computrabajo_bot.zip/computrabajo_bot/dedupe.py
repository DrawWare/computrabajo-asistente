"""Estado persistente (state.db) y pendientes.csv.

Dueño único de state.db: tabla `jobs` y tabla `daily_counter`.
Regla de idempotencia: un job con status `postulado` nunca se sobrescribe.
pendientes.csv: una fila por (job_id, motivo, pregunta); las corridas siguientes no la repiten.
Módulo sin navegador.
"""

from __future__ import annotations

import csv
import os
import re
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from filters import normalize

VALID_STATUS = ("visto", "descartado", "postulado", "pendiente", "error")
PENDIENTE_MOTIVOS = ("sin_cv", "pregunta_sin_regla")
PENDIENTES_HEADER = ["ts", "job_id", "title", "url", "motivo", "detalle", "pregunta", "tipo", "opciones"]
LEGACY_PENDIENTES_HEADER = PENDIENTES_HEADER[:6]  # formato hasta 2026-11-26 (sin pregunta/tipo/opciones)
OPTIONS_SEP = " | "  # separador de la columna "opciones"

# Columna "tipo": campo de la pregunta pendiente (lo informa apply._answer_questions).
KIND_RADIO = "radio"
KIND_SELECT = "select"
KIND_TEXT_NO_AI = "texto_sin_ia"  # texto sin regla y sin botón "Usar respuesta" (IA)
KIND_TEXT_AI_EMPTY = "texto_ia_vacia"  # texto sin regla; había botón "Usar respuesta" pero no llenó el campo
KIND_TEXT = "texto"  # filas del formato viejo: texto, sin el dato del botón IA
KIND_OTHER = "otro"  # tipo de campo no soportado

# Motivo entre paréntesis al final de "detalle" (textos de apply._answer_questions) → tipo. Sirve para
# completar las filas del formato viejo, que no tenían las columnas pregunta/tipo.
_REASON_KIND = {
    "sin opción segura en los radios": KIND_RADIO,
    "el paso de opción única no tiene opciones visibles": KIND_RADIO,
    "sin opción segura en el select": KIND_SELECT,
    "el select no tiene opciones": KIND_SELECT,
    "sin regla en responses.json ni respuesta sugerida": KIND_TEXT,
    "tipo de campo no soportado": KIND_OTHER,
}

_SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    job_id TEXT PRIMARY KEY,
    title TEXT,
    url TEXT,
    status TEXT NOT NULL,
    cv_used TEXT,
    ts TEXT,
    error TEXT
);
CREATE TABLE IF NOT EXISTS daily_counter (
    date TEXT PRIMARY KEY,
    count INTEGER NOT NULL DEFAULT 0,
    limit_reached_at TEXT
);
"""


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


class StateDB:
    """Wrapper de state.db. Usar como context manager o llamar close()."""

    def __init__(self, path: str | os.PathLike[str] = "state.db") -> None:
        self._conn = sqlite3.connect(str(path))
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "StateDB":
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()

    # --- jobs -------------------------------------------------------------

    def get_status(self, job_id: str) -> str | None:
        row = self._conn.execute(
            "SELECT status FROM jobs WHERE job_id = ?", (job_id,)
        ).fetchone()
        return row["status"] if row else None

    def upsert(
        self,
        job_id: str,
        title: str,
        url: str,
        status: str,
        cv_used: str | None = None,
        error: str | None = None,
        ts: str | None = None,
    ) -> bool:
        """Inserta o actualiza un job. Devuelve False (sin tocar nada) si ya está `postulado`."""
        if status not in VALID_STATUS:
            raise ValueError(f"status inválido: {status!r}")
        if self.get_status(job_id) == "postulado":
            return False
        self._conn.execute(
            """
            INSERT INTO jobs (job_id, title, url, status, cv_used, ts, error)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(job_id) DO UPDATE SET
                title = excluded.title,
                url = excluded.url,
                status = excluded.status,
                cv_used = excluded.cv_used,
                ts = excluded.ts,
                error = excluded.error
            WHERE jobs.status != 'postulado'
            """,
            (job_id, title, url, status, cv_used, ts or _now(), error),
        )
        self._conn.commit()
        return True

    # --- tope diario ------------------------------------------------------

    def get_daily_count(self, date: str | None = None) -> int:
        row = self._conn.execute(
            "SELECT count FROM daily_counter WHERE date = ?", (date or _today(),)
        ).fetchone()
        return row["count"] if row else 0

    def increment_daily_count(self, date: str | None = None) -> int:
        day = date or _today()
        self._conn.execute(
            """
            INSERT INTO daily_counter (date, count) VALUES (?, 1)
            ON CONFLICT(date) DO UPDATE SET count = count + 1
            """,
            (day,),
        )
        self._conn.commit()
        return self.get_daily_count(day)

    def remaining_quota(self, daily_limit: int, date: str | None = None) -> int:
        return max(0, daily_limit - self.get_daily_count(date))

    def mark_limit_reached(self, date: str | None = None, ts: str | None = None) -> None:
        """Registra la hora en que se alcanzó el tope (solo la primera vez del día)."""
        self._conn.execute(
            """
            INSERT INTO daily_counter (date, count, limit_reached_at) VALUES (?, 0, ?)
            ON CONFLICT(date) DO UPDATE SET
                limit_reached_at = COALESCE(daily_counter.limit_reached_at, excluded.limit_reached_at)
            """,
            (date or _today(), ts or _now()),
        )
        self._conn.commit()


    def statuses(self) -> dict[str, str]:
        """{job_id: status} de todos los avisos (para el resumen de pendientes)."""
        return {row["job_id"]: row["status"] for row in self._conn.execute("SELECT job_id, status FROM jobs")}


# ---------------------------------------------------------------------------
# pendientes.csv
# ---------------------------------------------------------------------------

PendienteRow = dict[str, str]


def question_key(text: str) -> str:
    """Clave para comparar preguntas: sin tildes ni mayúsculas, solo palabras ("¿Dónde vivís?" == "donde vivis")."""
    return " ".join(re.findall(r"[a-z0-9]+", normalize(text or "")))


def split_detalle(detalle: str) -> tuple[str, str]:
    """(pregunta, motivo) de un detalle "<pregunta> (<motivo>)"; si el motivo no es conocido, (detalle, "")."""
    text = (detalle or "").strip()
    for reason in _REASON_KIND:
        suffix = f" ({reason})"
        if text.endswith(suffix):
            return text[: -len(suffix)].strip(), reason
    return text, ""


def split_options(opciones: str) -> list[str]:
    """Lista de opciones de la columna "opciones"."""
    return [o.strip() for o in (opciones or "").split(OPTIONS_SEP.strip()) if o.strip()]


def _complete(row: Mapping[str, str | None]) -> PendienteRow:
    """Fila con todas las columnas actuales. En filas viejas deduce pregunta y tipo desde "detalle"."""
    out = {col: (row.get(col) or "").strip() for col in PENDIENTES_HEADER}
    if out["motivo"] == "pregunta_sin_regla" and not (out["pregunta"] and out["tipo"]):
        question, reason = split_detalle(out["detalle"])
        out["pregunta"] = out["pregunta"] or question
        out["tipo"] = out["tipo"] or _REASON_KIND.get(reason, "")
    return out


def pending_key(row: Mapping[str, str]) -> tuple[str, str, str]:
    """Identidad de una pendiente: (job_id, motivo, pregunta normalizada)."""
    return row["job_id"], row["motivo"], question_key(row["pregunta"])


def _merge(kept: PendienteRow, repeated: PendienteRow) -> bool:
    """Completa la fila guardada con lo que trae una repetida. True si cambió algo.

    Se conservan ts y detalle de la primera detección; título, URL, tipo y opciones se completan si faltaban.
    Un tipo genérico del formato viejo ("texto") se reemplaza por el detallado ("texto_sin_ia").
    """
    changed = False
    for col in ("title", "url", "opciones"):
        if not kept[col] and repeated[col]:
            kept[col] = repeated[col]
            changed = True
    if repeated["tipo"] and kept["tipo"] != repeated["tipo"] and kept["tipo"] in ("", KIND_TEXT):
        kept["tipo"] = repeated["tipo"]
        changed = True
    return changed


def dedupe_pendientes(rows: Iterable[Mapping[str, str | None]]) -> list[PendienteRow]:
    """Una fila por ``pending_key``, en orden de aparición; las repetidas solo completan campos vacíos."""
    kept: dict[tuple[str, str, str], PendienteRow] = {}
    for raw in rows:
        row = _complete(raw)
        key = pending_key(row)
        if key in kept:
            _merge(kept[key], row)
        else:
            kept[key] = row
    return list(kept.values())


def _load_pendientes(path: Path) -> tuple[list[PendienteRow], bool]:
    """(filas completadas al formato actual, sin deduplicar; True si el header ya es el actual)."""
    if not path.exists() or path.stat().st_size == 0:
        return [], False
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = [_complete(row) for row in reader]
        return rows, reader.fieldnames == PENDIENTES_HEADER


def read_pendientes(csv_path: str | os.PathLike[str]) -> list[PendienteRow]:
    """Filas de pendientes.csv en el formato actual (acepta el de 6 columnas), sin deduplicar."""
    return _load_pendientes(Path(csv_path))[0]


def write_pendientes(csv_path: str | os.PathLike[str], rows: Iterable[Mapping[str, str]]) -> None:
    """Reescribe pendientes.csv completo: header actual, UTF-8 con BOM (abre bien en Excel).

    Escribe a un temporal y lo renombra: un corte a mitad de escritura no deja el CSV truncado.
    OSError si el archivo está bloqueado (p. ej. abierto en Excel).
    """
    path = Path(csv_path)
    tmp = path.with_name(path.name + ".tmp")
    try:
        with tmp.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=PENDIENTES_HEADER, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def compact_pendientes(csv_path: str | os.PathLike[str]) -> tuple[int, int]:
    """Deduplica pendientes.csv en el lugar y lo pasa al formato actual. Devuelve (filas antes, filas después)."""
    path = Path(csv_path)
    rows, current_header = _load_pendientes(path)
    unique = dedupe_pendientes(rows)
    if rows and (len(unique) != len(rows) or not current_header):
        write_pendientes(path, unique)
    return len(rows), len(unique)


def append_pendiente(
    csv_path: str | os.PathLike[str],
    job_id: str,
    title: str,
    url: str,
    motivo: str,
    detalle: str = "",
    ts: str | None = None,
    *,
    pregunta: str = "",
    tipo: str = "",
    opciones: Sequence[str] = (),
) -> bool:
    """Registra una pendiente en pendientes.csv sin duplicar (job_id, motivo, pregunta).

    Devuelve True si agregó una fila; False si esa pendiente ya estaba (de una corrida anterior): en ese
    caso solo completa en la fila existente el tipo y las opciones que le faltaran. ``pregunta`` vacía =>
    se deduce de ``detalle`` ("<pregunta> (<motivo>)").
    El archivo queda deduplicado y en el formato actual (migra el de 6 columnas), UTF-8 con BOM.
    """
    if motivo not in PENDIENTE_MOTIVOS:
        raise ValueError(f"motivo inválido: {motivo!r}")
    path = Path(csv_path)
    existing, current_header = _load_pendientes(path)
    rows = dedupe_pendientes(existing)
    needs_rewrite = len(rows) != len(existing) or not current_header

    new = _complete(
        {
            "ts": ts or _now(),
            "job_id": job_id,
            "title": title,
            "url": url,
            "motivo": motivo,
            "detalle": detalle,
            "pregunta": pregunta,
            "tipo": tipo,
            "opciones": OPTIONS_SEP.join(o.strip() for o in opciones if o and o.strip()),
        }
    )
    key = pending_key(new)
    duplicate = next((row for row in rows if pending_key(row) == key), None)
    if duplicate is not None:
        if _merge(duplicate, new) or needs_rewrite:
            write_pendientes(path, rows)
        return False
    rows.append(new)
    write_pendientes(path, rows)
    return True
