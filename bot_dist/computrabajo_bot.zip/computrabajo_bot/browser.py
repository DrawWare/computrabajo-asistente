"""Contexto de navegador persistente y helpers de espera.

Siempre headful (visible): prohibido headless.
El perfil persistente (cookies/sesión) se reutiliza entre corridas.
Excepciones de control: SessionExpiredError (detiene todo),
CaptchaTimeoutError y PageLoadTimeoutError (el orquestador marca `error` y sigue).
"""

from __future__ import annotations

import logging
import random
import re
import time
from dataclasses import dataclass
from pathlib import Path

from playwright.sync_api import (
    BrowserContext,
    Page,
    Playwright,
    TimeoutError as PlaywrightTimeoutError,
    sync_playwright,
)

import page_selectors as sel

logger = logging.getLogger(__name__)


class SessionExpiredError(RuntimeError):
    """La sesión redirigió a login o mostró mensaje de sesión expirada."""


class CaptchaTimeoutError(RuntimeError):
    """El CAPTCHA no se resolvió dentro de captcha_timeout."""


class PageLoadTimeoutError(RuntimeError):
    """La página no cargó dentro de page_timeout."""


@dataclass
class BrowserSession:
    """Agrupa lo que hay que cerrar al final: Playwright, contexto y pestaña principal."""

    playwright: Playwright
    context: BrowserContext
    page: Page

    def close(self) -> None:
        try:
            self.context.close()
        finally:
            self.playwright.stop()


def open_context(profile_dir: str | Path, page_timeout: float) -> BrowserSession:
    """Abre Chromium headful con perfil persistente.

    ``page_timeout`` en segundos; se aplica como timeout por defecto de
    acciones y de navegación del contexto.
    """
    profile_path = Path(profile_dir)
    profile_path.mkdir(parents=True, exist_ok=True)

    timeout_ms = float(page_timeout) * 1000
    playwright = sync_playwright().start()
    try:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(profile_path),
            headless=False,
        )
        context.set_default_timeout(timeout_ms)
        context.set_default_navigation_timeout(timeout_ms)
        page = context.pages[0] if context.pages else context.new_page()
    except Exception:
        playwright.stop()
        raise

    logger.info("Navegador abierto (perfil=%s, page_timeout=%ss)", profile_path, page_timeout)
    return BrowserSession(playwright=playwright, context=context, page=page)


def safe_goto(page: Page, url: str) -> None:
    """Navega a ``url``. Timeout => PageLoadTimeoutError."""
    try:
        page.goto(url, wait_until="domcontentloaded")
    except PlaywrightTimeoutError as exc:
        raise PageLoadTimeoutError(f"Timeout cargando {url}") from exc


def check_session(page: Page) -> None:
    """Lanza SessionExpiredError si la página indica que no hay sesión activa."""
    if re.search(sel.LOGIN_URL_PATTERN, page.url, re.IGNORECASE):
        raise SessionExpiredError(f"Redirigido a login: {page.url}")

    if page.locator(sel.LOGIN_PASSWORD_INPUT).first.is_visible():
        raise SessionExpiredError(f"Formulario de login visible en {page.url}")

    for text in sel.SESSION_EXPIRED_TEXTS:
        if page.get_by_text(text, exact=False).first.is_visible():
            raise SessionExpiredError(f"Mensaje de sesión expirada: '{text}'")


def _captcha_present(page: Page) -> bool:
    if re.search(sel.CAPTCHA_URL_PATTERN, page.url, re.IGNORECASE):
        return True
    return page.locator(sel.CAPTCHA_IFRAME).first.is_visible()


def wait_captcha_if_present(page: Page, timeout: float, poll_s: float = 2.0) -> bool:
    """Si hay CAPTCHA, espera su resolución manual (poll cada ``poll_s``).

    Devuelve True si había CAPTCHA y se resolvió, False si no había.
    Expira => CaptchaTimeoutError.
    """
    if not _captcha_present(page):
        return False

    logger.warning("CAPTCHA detectado en %s: resolver manualmente (timeout %ss)", page.url, timeout)
    deadline = time.monotonic() + float(timeout)
    while _captcha_present(page):
        if time.monotonic() >= deadline:
            raise CaptchaTimeoutError(f"CAPTCHA no resuelto en {timeout}s")
        time.sleep(poll_s)

    logger.info("CAPTCHA resuelto")
    return True


def human_pause(min_s: float, max_s: float) -> float:
    """Pausa aleatoria uniforme en [min_s, max_s]. Devuelve la duración usada."""
    duration = random.uniform(min_s, max_s)
    logger.info("Pausa %.1fs", duration)
    time.sleep(duration)
    return duration
