"""Selección de CV (y pretensión salarial) según palabras clave del aviso.

El CV se identifica por su **etiqueta exacta** tal como aparece en Computrabajo
(Mi currículum > Currículum en Word/PDF, que es el nombre de archivo original). El bot
NO sube archivos: elige uno de los CVs ya precargados en la cuenta (ver `select_cv_by_label`
en apply.py), por lo que no se valida nada contra el disco.

Prioridad: match en título > match en descripción; desempate por orden de reglas
(la primera regla de la lista gana). La descripción solo decide si ninguna regla matchea el título.
Módulo puro: sin I/O.
"""

from __future__ import annotations

import re
from typing import Mapping, Sequence

from filters import keyword_pattern, normalize

CvRule = Mapping[str, object]  # {"keywords": [...], "cv_label": "...", "salary_net": int, "salary_gross": int}

# Sobre texto normalizado (sin tildes, minúsculas): "pasantía" => "pasantia".
_PART_TIME_OR_TRAINEE = re.compile(r"(?<!\w)(part[ -]?time|medio tiempo|trainee|pasantia)(?!\w)")


def _first_rule_matching(text: str, rules: Sequence[CvRule]) -> CvRule | None:
    normalized = normalize(text)
    for rule in rules:
        for keyword in rule["keywords"]:  # type: ignore[union-attr]
            if keyword and keyword.strip() and keyword_pattern(keyword).search(normalized):
                return rule
    return None


def choose_rule(title: str, description: str | None, rules: Sequence[CvRule]) -> CvRule | None:
    """Regla completa (CV + salario) para el aviso, o None si ninguna matchea.

    Dos pasadas: primero TODAS las reglas contra el título; la descripción solo se mira si ninguna regla
    matchea el título. Así una regla de baja prioridad que matchea el título gana a una de alta prioridad
    que solo aparece en la descripción (texto largo del panel: "software", "sistemas", "redes"...).
    Un título sin keywords de ninguna regla ("Analista", "Soporte") queda en manos de la descripción.
    """
    by_title = _first_rule_matching(title or "", rules)
    if by_title is not None:
        return by_title
    return _first_rule_matching(description or "", rules)


def choose_cv(
    title: str,
    description: str | None,
    rules: Sequence[CvRule],
    default_cv_label: str | None,
) -> str | None:
    """Devuelve la etiqueta del CV precargado a elegir, o default_cv_label (puede ser None)."""
    rule = choose_rule(title, description, rules)
    return str(rule["cv_label"]) if rule is not None else default_cv_label


def salary_for(
    rule: CvRule,
    title: str,
    description: str | None,
    part_time_factor: float = 1.0,
) -> dict[str, int] | None:
    """Pretensión {"neto", "bruto"} para la regla. Part-time o trainee => multiplicada por el factor.

    Devuelve None si la regla no tiene salario configurado. Redondea a miles.
    """
    if "salary_net" not in rule or "salary_gross" not in rule:
        return None
    factor = part_time_factor if _PART_TIME_OR_TRAINEE.search(normalize(f"{title or ''} {description or ''}")) else 1.0

    def _amount(value: object) -> int:
        return int(round(float(value) * factor / 1000) * 1000)  # type: ignore[arg-type]

    return {"neto": _amount(rule["salary_net"]), "bruto": _amount(rule["salary_gross"])}


def labels_equal(a: str | None, b: str | None) -> bool:
    """True si dos etiquetas de CV son la misma, sin importar tildes, mayúsculas o espacios.

    Sirve para comparar la etiqueta del YAML con el ``data-val-fname`` del sitio, que puede
    venir con otra forma Unicode de la ñ.
    """
    if not a or not b:
        return False
    return normalize(a) == normalize(b)


def _check_label(label: object, where: str) -> None:
    if not isinstance(label, str) or not label.strip():
        raise ValueError(f"{where} debe ser un texto no vacío (etiqueta exacta del CV en Computrabajo)")
    if "/" in label or "\\" in label:
        raise ValueError(
            f"{where} = {label!r} parece una ruta; usá solo la etiqueta (nombre de archivo) "
            "como aparece en Computrabajo, sin carpetas"
        )


def _check_salary(rule: CvRule, index: int) -> None:
    has_net, has_gross = "salary_net" in rule, "salary_gross" in rule
    if has_net != has_gross:
        raise ValueError(f"cv_rules[{index}]: salary_net y salary_gross deben estar los dos o ninguno")
    if has_net:
        for key in ("salary_net", "salary_gross"):
            value = rule[key]
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"cv_rules[{index}].{key} debe ser un entero positivo")
        if rule["salary_net"] > rule["salary_gross"]:  # type: ignore[operator]
            raise ValueError(f"cv_rules[{index}]: salary_net no puede superar salary_gross")


def validate_cv_rules(rules: Sequence[CvRule], default_cv_label: str | None) -> None:
    """Valida la forma de cv_rules al arrancar. No toca el disco ni el sitio."""
    for index, rule in enumerate(rules):
        if "keywords" not in rule or "cv_label" not in rule:
            raise ValueError(f"cv_rules[{index}] debe tener 'keywords' y 'cv_label'")
        keywords = rule["keywords"]
        if not isinstance(keywords, (list, tuple)) or not keywords:
            raise ValueError(f"cv_rules[{index}].keywords debe ser una lista no vacía")
        _check_label(rule["cv_label"], f"cv_rules[{index}].cv_label")
        _check_salary(rule, index)
    if default_cv_label is not None:
        _check_label(default_cv_label, "default_cv_label")
