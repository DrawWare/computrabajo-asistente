"""Configuración de ubicación e inglés (6.2.1): lee ``location`` y ``english_block_terms`` de config.yaml.

Puro: no lee disco. Errores => ValueError (main.py y pending_report.py los convierten en error de configuración).
Sin claves => defaults = comportamiento de Córdoba (``DEFAULT_LOCATION`` / ``DEFAULT_HOME``).
"""

from __future__ import annotations

from typing import Any, Mapping

from filters import (
    CORDOBA_TERMS,
    DEFAULT_LOCATION,
    ENGLISH_BLOCK_TERMS,
    MODALITIES,
    ZONA_SUR_TERMS,
    LocationRules,
)
from questions import DEFAULT_HOME, HomeLocation, home_from_terms


def _texts(value: Any, key: str, *, allow_empty: bool) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
        raise ValueError(f"{key} debe ser una lista de textos no vacíos")
    if not allow_empty and not value:
        raise ValueError(f"{key} no puede estar vacía")
    return tuple(value)


def parse_location(raw: Mapping[str, Any]) -> tuple[LocationRules, HomeLocation]:
    """``location`` (mapa opcional) => reglas de modalidad y lugar de residencia."""
    location = raw.get("location")
    if location is None:
        return DEFAULT_LOCATION, DEFAULT_HOME
    if not isinstance(location, dict):
        raise ValueError("location debe ser un mapa")

    home_terms = _texts(location.get("home_terms", list(CORDOBA_TERMS)), "location.home_terms", allow_empty=False)
    zone = location.get("presencial_zone_terms")
    zone_terms = ZONA_SUR_TERMS if zone is None else _texts(zone, "location.presencial_zone_terms", allow_empty=True)

    modalities = location.get("modalities", list(MODALITIES))
    if not isinstance(modalities, list) or not modalities or any(m not in MODALITIES for m in modalities):
        raise ValueError(f"location.modalities debe ser una lista no vacía de: {', '.join(MODALITIES)}")

    rules = LocationRules(home_terms, zone_terms, tuple(dict.fromkeys(modalities)))
    return rules, home_from_terms(home_terms)


def parse_english_terms(raw: Mapping[str, Any]) -> tuple[str, ...]:
    """``english_block_terms`` (lista, puede ser vacía para no descartar por inglés) o los defaults."""
    value = raw.get("english_block_terms")
    if value is None:
        return ENGLISH_BLOCK_TERMS
    return _texts(value, "english_block_terms", allow_empty=True)
