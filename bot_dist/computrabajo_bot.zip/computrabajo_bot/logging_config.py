"""Logging estructurado: consola + archivo diario logs/bot_YYYYMMDD.log.

Formato: ``ts | level | módulo | mensaje``.
Niveles: INFO acciones normales, WARNING pendientes/descartados, ERROR fallos.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path

LOG_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Marca para identificar los handlers creados por este módulo y no duplicarlos
# si setup_logging se llama más de una vez en la misma corrida.
_HANDLER_MARK = "_computrabajo_bot_handler"

# Resultado -> nivel de log para log_job.
_RESULT_LEVELS = {
    "postulado": logging.INFO,
    "visto": logging.INFO,
    "pendiente": logging.WARNING,
    "descartado": logging.WARNING,
    "error": logging.ERROR,
}


def setup_logging(log_dir: str | Path = "logs") -> Path:
    """Configura el logger raíz con salida a consola y a logs/bot_YYYYMMDD.log.

    Devuelve la ruta del archivo de log de hoy.
    """
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    file_path = log_path / f"bot_{datetime.now():%Y%m%d}.log"

    root = logging.getLogger()
    root.setLevel(logging.INFO)

    # Limpiar handlers previos creados por este módulo.
    for handler in list(root.handlers):
        if getattr(handler, _HANDLER_MARK, False):
            root.removeHandler(handler)
            handler.close()

    formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    setattr(console, _HANDLER_MARK, True)

    file_handler = logging.FileHandler(file_path, encoding="utf-8")
    file_handler.setFormatter(formatter)
    setattr(file_handler, _HANDLER_MARK, True)

    root.addHandler(console)
    root.addHandler(file_handler)
    return file_path


def log_job(
    logger: logging.Logger,
    job_id: str,
    title: str,
    cv: str | None,
    result: str,
    detail: str | None = None,
) -> None:
    """Deja una traza por aviso: job_id, título, CV usado y resultado.

    ``result`` es el status final (postulado | visto | pendiente | descartado | error).
    El nivel se elige según el resultado (ver ``_RESULT_LEVELS``).
    """
    level = _RESULT_LEVELS.get(result, logging.INFO)
    msg = f"job_id={job_id} | titulo={title} | cv={cv or '-'} | resultado={result}"
    if detail:
        msg += f" | detalle={detail}"
    logger.log(level, msg)
