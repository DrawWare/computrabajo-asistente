"""Orquestador del bot: CLI y flujo de GUIA.md §FLUJO DE main.py (tarea 5.1).

Uso (desde computrabajo_bot/):
    python main.py --dry-run            # recorre y elige CV y pretensión; NO clica "Postularme"
    python main.py --limit 1            # postula como máximo 1 aviso en esta corrida
    python main.py --search 0           # solo la búsqueda con índice 0 de config.yaml
    python main.py --profile ana --dry-run   # perfil aislado: profiles/ana/ (sin --profile = raíz, perfil default)
    python main.py --import-bundle perfil_ana.zip [--profile ana] [--force]   # instala un bundle del wizard y sale
    python main.py --profile ana --login   # abre el navegador del perfil en el login; guarda la sesión y sale

Reglas:
- Un aviso ``postulado`` en state.db nunca se vuelve a procesar.
- ``--dry-run`` no clica "Postularme": en avisos sin cuestionario ese clic ya postula (5.2b). Por eso
  tampoco ve las preguntas del cuestionario.
- Corrida real: un aviso sin cuestionario queda ``postulado`` al clicar "Postularme" y cuenta en el tope
  diario; el CV elegido se pone después, desde la caja de confirmación.
- ``--limit`` nunca supera el remanente del tope diario (``daily_limit``).
- Sin regla de CV que matchee el aviso => ``descartado`` (motivo ``sin_cv``).
  ``pendientes.csv`` solo recibe preguntas sin regla en responses.json, una vez por (aviso, pregunta).
  Al final de cada corrida se regenera ``pendientes_resumen.md`` (pending_report.py).
- Cada aviso se abre clicando su tarjeta en el listado (panel derecho, sin navegar). Con el panel abierto
  se lee la descripción y recién entonces ``evaluate_job`` y ``choose_rule`` reciben ``description``.

Códigos de salida: 0 OK · 1 configuración o uso inválido · 2 sesión expirada (re-loguearse y volver a correr)
· 130 interrumpido con Ctrl+C.
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import yaml
from playwright.sync_api import Error as PlaywrightError, Page, TimeoutError as PlaywrightTimeoutError

import apply
from apply import ApplyResult, read_description, run_apply
from page_selectors import LOGIN_PAGE_URL
from browser import (
    CaptchaTimeoutError,
    PageLoadTimeoutError,
    SessionExpiredError,
    check_session,
    human_pause,
    open_context,
    safe_goto,
)
from cv_router import choose_rule, salary_for, validate_cv_rules
from dedupe import StateDB, append_pendiente
from filters import DEFAULT_LOCATION, ENGLISH_BLOCK_TERMS, LocationRules, evaluate_job, title_problem
from logging_config import log_job, setup_logging
from pending_report import REPORT_NAME, update_pending_files
from profiles import (
    DEFAULT_PROFILE,
    ProfileError,
    ProfilePaths,
    install_bundle,
    list_profiles,
    named_paths,
    read_bundle,
    require_existing_profile,
)
from location_config import parse_english_terms, parse_location
from questions import DEFAULT_HOME, HomeLocation, incomplete_rules, placeholders
from search import CardNotFoundError, JobCard, iter_jobs, open_card

logger = logging.getLogger("main")

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.yaml"
RESPONSES_PATH = BASE_DIR / "responses.json"
STATE_DB_PATH = BASE_DIR / "state.db"
PENDIENTES_PATH = BASE_DIR / "pendientes.csv"
PENDIENTES_REPORT_PATH = BASE_DIR / REPORT_NAME
PROFILE_DIR = BASE_DIR / "profile"
LOG_DIR = BASE_DIR / "logs"

DEFAULT_MAX_PAGES = 3

EXIT_OK = 0
EXIT_CONFIG = 1
EXIT_SESSION = 2
EXIT_INTERRUPTED = 130


class ConfigError(ValueError):
    """config.yaml o responses.json inválidos, o argumentos de CLI fuera de rango."""


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _positive_int(text: str) -> int:
    try:
        value = int(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"se esperaba un entero, no {text!r}") from exc
    if value < 1:
        raise argparse.ArgumentTypeError("debe ser >= 1")
    return value


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="Bot de postulaciones a Computrabajo (Chromium visible, perfil persistente).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="recorre avisos y elige CV y pretensión, pero NO clica 'Postularme' (no responde ni envía nada)",
    )
    parser.add_argument(
        "--limit",
        type=_positive_int,
        metavar="N",
        help="máximo de postulaciones (o de dry-runs OK) en esta corrida; nunca supera el tope diario restante",
    )
    parser.add_argument(
        "--search",
        type=int,
        metavar="IDX",
        help="procesa solo la búsqueda con ese índice en config.yaml (debe estar habilitada)",
    )
    parser.add_argument(
        "--profile",
        metavar="NAME",
        default=None,
        help="perfil aislado en profiles/NAME/ (requiere su config.yaml); sin la opción se usa la raíz (perfil 'default')",
    )
    parser.add_argument(
        "--import-bundle",
        metavar="ZIP",
        default=None,
        help="instala un bundle del wizard (perfil_<slug>.zip o su carpeta descomprimida) en profiles/<slug>/ y sale; no abre el navegador",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="con --import-bundle: reemplaza config.yaml y responses.json del perfil (guarda .bak)",
    )
    parser.add_argument(
        "--login",
        action="store_true",
        help="abre el navegador del perfil en la página de login, espera a que inicies sesión y guarda la sesión; no postula",
    )
    parser.add_argument(
        "--list-profiles",
        action="store_true",
        help="lista el perfil 'default' (raíz) y los perfiles de profiles/ con config.yaml, y sale",
    )
    return parser.parse_args(argv)


# ---------------------------------------------------------------------------
# Configuración
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Settings:
    searches: list[dict[str, Any]]
    daily_limit: int
    delay_min: float
    delay_max: float
    title_keywords: list[str]
    desc_keywords: list[str]
    required_title_keywords: list[str]
    cv_rules: list[dict[str, Any]]
    default_cv_label: str | None
    part_time_factor: float
    page_timeout: float
    captcha_timeout: float
    max_pages: int
    location_rules: LocationRules = DEFAULT_LOCATION  # 6.2.1: al final, con default
    home: HomeLocation = DEFAULT_HOME
    english_terms: tuple[str, ...] = ENGLISH_BLOCK_TERMS


def _number(raw: Mapping[str, Any], key: str, default: float, minimum: float = 0) -> float:
    value = raw.get(key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value < minimum:
        raise ConfigError(f"{key} debe ser un número >= {minimum}")
    return float(value)


def _string_list(raw: Mapping[str, Any], key: str) -> list[str]:
    value = raw.get(key) or []
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ConfigError(f"{key} debe ser una lista de textos")
    return value


def parse_settings(raw: Mapping[str, Any]) -> Settings:
    """Valida el dict de config.yaml. Lanza ConfigError con un mensaje legible."""
    searches = raw.get("searches")
    if not isinstance(searches, list) or not searches:
        raise ConfigError("searches debe ser una lista no vacía")
    for index, search in enumerate(searches):
        url = search.get("url") if isinstance(search, dict) else None
        if not isinstance(url, str) or not url.startswith("https://"):
            raise ConfigError(f"searches[{index}]: falta una 'url' https válida")
        if not isinstance(search.get("enabled", True), bool):
            raise ConfigError(f"searches[{index}].enabled debe ser true o false")

    daily_limit = raw.get("daily_limit")
    if isinstance(daily_limit, bool) or not isinstance(daily_limit, int) or daily_limit < 1:
        raise ConfigError("daily_limit debe ser un entero >= 1")

    delays = raw.get("delays") or {}
    if not isinstance(delays, dict):
        raise ConfigError("delays debe tener 'min' y 'max'")
    delay_min = _number(delays, "min", 4)
    delay_max = _number(delays, "max", 12)
    if delay_min > delay_max:
        raise ConfigError("delays.min no puede superar delays.max")

    cv_rules = raw.get("cv_rules") or []
    default_cv_label = raw.get("default_cv_label")
    if default_cv_label is not None and not isinstance(default_cv_label, str):
        raise ConfigError("default_cv_label debe ser null o un texto")
    try:
        validate_cv_rules(cv_rules, default_cv_label)
    except ValueError as exc:
        raise ConfigError(str(exc)) from exc

    part_time_factor = _number(raw, "salary_part_time_factor", 1.0)
    if part_time_factor <= 0:
        raise ConfigError("salary_part_time_factor debe ser > 0")

    max_pages = int(_number(raw, "max_pages", DEFAULT_MAX_PAGES, minimum=1))

    try:
        location_rules, home = parse_location(raw)
        english_terms = parse_english_terms(raw)
    except ValueError as exc:
        raise ConfigError(str(exc)) from exc

    return Settings(
        searches=searches,
        daily_limit=daily_limit,
        delay_min=delay_min,
        delay_max=delay_max,
        title_keywords=_string_list(raw, "exclude_title_keywords"),
        desc_keywords=_string_list(raw, "exclude_desc_keywords"),
        required_title_keywords=_string_list(raw, "required_title_keywords"),
        cv_rules=cv_rules,
        default_cv_label=default_cv_label,
        part_time_factor=part_time_factor,
        page_timeout=_number(raw, "page_timeout", 30, minimum=1),
        captcha_timeout=_number(raw, "captcha_timeout", 180, minimum=1),
        max_pages=max_pages,
        location_rules=location_rules,
        home=home,
        english_terms=english_terms,
    )


def load_settings(path: Path = CONFIG_PATH) -> Settings:
    try:
        with path.open(encoding="utf-8") as handle:
            raw = yaml.safe_load(handle) or {}
    except (OSError, yaml.YAMLError) as exc:
        raise ConfigError(f"no se pudo leer {path.name}: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError(f"{path.name} debe ser un mapa YAML")
    return parse_settings(raw)


def parse_responses(data: Any) -> list[dict[str, str]]:
    if not isinstance(data, list):
        raise ConfigError("responses.json debe ser una lista de reglas")
    for index, rule in enumerate(data):
        if not isinstance(rule, dict) or not isinstance(rule.get("pattern"), str) or not isinstance(rule.get("answer"), str):
            raise ConfigError(f"responses.json[{index}]: se esperan 'pattern' y 'answer' como textos")
        if "option" in rule and not isinstance(rule["option"], str):
            raise ConfigError(f"responses.json[{index}].option debe ser un texto (opción de radio/select)")
        try:
            re.compile(rule["pattern"])
        except re.error as exc:
            raise ConfigError(f"responses.json[{index}].pattern no es una regex válida: {exc}") from exc
    return data


def load_responses(path: Path = RESPONSES_PATH) -> list[dict[str, str]]:
    try:
        with path.open(encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise ConfigError(f"no se pudo leer {path.name}: {exc}") from exc
    return parse_responses(data)


def warn_incomplete_rules(responses: Sequence[Mapping[str, str]]) -> int:
    """Avisa en el log por cada regla con un placeholder sin completar ("[COMPLETAR_TELEFONO]").

    Esas reglas no se usan (``questions.match_rule`` las saltea): el bot nunca envía el placeholder.
    Devuelve cuántas hay.
    """
    rules = incomplete_rules(responses)
    for rule in rules:
        logger.warning(
            "responses.json: la regla %r tiene %s sin completar; no se usa hasta que lo completes",
            rule["pattern"][:60], ", ".join(placeholders(rule)),
        )
    return len(rules)


def select_searches(searches: Sequence[Mapping[str, Any]], index: int | None) -> list[tuple[int, Mapping[str, Any]]]:
    """Búsquedas a correr, con su índice original en config.yaml."""
    if index is None:
        return [(i, s) for i, s in enumerate(searches) if s.get("enabled", True)]
    if not 0 <= index < len(searches):
        raise ConfigError(f"--search {index} fuera de rango (0..{len(searches) - 1})")
    if not searches[index].get("enabled", True):
        raise ConfigError(f"la búsqueda {index} está deshabilitada en config.yaml")
    return [(index, searches[index])]


# ---------------------------------------------------------------------------
# Decisión por aviso (pura)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Plan:
    action: str  # "descartar" | "aplicar"
    motivo: str | None = None  # si descartar: motivo del filtro o "sin_cv"
    cv_label: str | None = None  # si aplicar: CV precargado a elegir
    salary: dict[str, int] | None = None  # si aplicar: {"neto", "bruto"} del rol; None => responses.json


def plan_job(title: str, location: str, description: str | None, settings: Settings) -> Plan:
    """Filtros (GUIA paso c) y elección de CV + pretensión (paso f). ``description`` = texto del panel abierto."""
    problem = evaluate_job(
        title,
        description,
        title_keywords=settings.title_keywords,
        desc_keywords=settings.desc_keywords,
        location=location,
        required_title_keywords=settings.required_title_keywords,
        location_rules=settings.location_rules,
        english_terms=settings.english_terms,
    )
    if problem:
        return Plan("descartar", motivo=problem)

    rule = choose_rule(title, description, settings.cv_rules)
    if rule is not None:
        salary = salary_for(rule, title, description, settings.part_time_factor)
        return Plan("aplicar", cv_label=str(rule["cv_label"]), salary=salary)

    if settings.default_cv_label:
        return Plan("aplicar", cv_label=settings.default_cv_label)

    # Decisión 2026-11-26: sin regla de CV => descartado (no pendiente).
    return Plan("descartar", motivo="sin_cv")


# ---------------------------------------------------------------------------
# Corrida
# ---------------------------------------------------------------------------


@dataclass
class Summary:
    searches_ok: int = 0
    searches_error: int = 0
    postulados: int = 0
    ya_postulados: int = 0
    dry_run_ok: int = 0
    pendientes: int = 0
    descartados: int = 0
    errores: int = 0
    ya_en_state: int = 0
    repetidos_en_corrida: int = 0
    stop_reason: str = "fin de las búsquedas"


@dataclass
class RunContext:
    page: Page
    db: StateDB
    settings: Settings
    responses: list[dict[str, str]]
    dry_run: bool
    cap: int  # máximo de postulaciones (o dry-runs OK) en esta corrida
    summary: Summary = field(default_factory=Summary)
    counted: int = 0
    done: bool = False
    seen_this_run: set[str] = field(default_factory=set)
    paths: ProfilePaths | None = None  # None => constantes de módulo (PENDIENTES_PATH, ...)


def _save(ctx: RunContext, card: JobCard, status: str, cv: str | None = None, error: str | None = None) -> None:
    ctx.db.upsert(card.job_id, card.title, card.url, status, cv_used=cv, error=error)


def _register_pending_question(card: JobCard, result: Any, csv_path: Path | None = None) -> None:
    """Agrega la pregunta sin regla a pendientes.csv, sin repetir (job_id, pregunta) de corridas anteriores.

    Un CSV bloqueado (abierto en Excel) no corta la corrida: queda el aviso en el log.
    """
    question = result.pending_questions[0] if result.pending_questions else ""
    try:
        added = append_pendiente(
            csv_path or PENDIENTES_PATH,
            card.job_id,
            card.title,
            card.url,
            result.motivo,
            result.detalle,
            pregunta=question,
            tipo=result.pending_kind,
            opciones=result.pending_options,
        )
    except OSError as exc:
        logger.warning("No se pudo escribir pendientes.csv (¿abierto en Excel?): %s", exc)
        return
    if not added:
        logger.info("job_id=%s pregunta ya registrada en pendientes.csv: %s", card.job_id, question)


def _record(ctx: RunContext, card: JobCard, plan: Plan, result: Any) -> None:
    sm = ctx.summary
    status = result.status

    if status == "postulado":
        # También los avisos sin cuestionario (el clic en "Postularme" ya postuló). result.error = por qué no
        # se pudo poner el CV elegido: queda en state.db para revisar esa postulación en el sitio.
        _save(ctx, card, "postulado", cv=result.cv_used, error=result.error)
        ctx.db.increment_daily_count()
        sm.postulados += 1
        ctx.counted += 1
        detail = "; ".join(part for part in (result.detalle, result.error) if part) or None
        log_job(logger, card.job_id, card.title, result.cv_used, "postulado", detail)
        if ctx.db.remaining_quota(ctx.settings.daily_limit) == 0:
            ctx.db.mark_limit_reached()
            ctx.done = True
            sm.stop_reason = "tope diario alcanzado"

    elif status == "ya_postulado":
        _save(ctx, card, "postulado")
        sm.ya_postulados += 1
        log_job(logger, card.job_id, card.title, None, "postulado", result.detalle or "ya postulado en el sitio")

    elif status == "dry_run":
        # No se clicó "Postularme". El estado queda en "visto": un dry-run no bloquea la corrida real.
        sm.dry_run_ok += 1
        ctx.counted += 1
        log_job(
            logger, card.job_id, card.title, result.cv_used, "visto",
            f"dry-run, sin clic en Postularme | {result.detalle}",
        )

    elif status == "pendiente":
        _save(ctx, card, "pendiente", error=result.motivo)
        sm.pendientes += 1
        detail = f"{result.motivo}: {result.detalle}"
        if result.motivo == "pregunta_sin_regla":
            _register_pending_question(card, result, ctx.paths.pendientes if ctx.paths else None)
        log_job(logger, card.job_id, card.title, plan.cv_label, "pendiente", detail)

    elif status in ("sin_boton", "descartado"):
        motivo = result.motivo or status
        _save(ctx, card, "descartado", error=motivo)
        sm.descartados += 1
        log_job(logger, card.job_id, card.title, None, "descartado", motivo)

    else:  # "error"
        _save(ctx, card, "error", error=result.error)
        sm.errores += 1
        log_job(logger, card.job_id, card.title, plan.cv_label, "error", result.error)

    if not ctx.done and ctx.counted >= ctx.cap:
        ctx.done = True
        sm.stop_reason = f"máximo de la corrida alcanzado ({ctx.cap})"


def process_card(ctx: RunContext, card: JobCard) -> None:
    sm = ctx.summary
    if card.job_id in ctx.seen_this_run:
        sm.repetidos_en_corrida += 1
        return
    ctx.seen_this_run.add(card.job_id)

    if ctx.db.get_status(card.job_id) == "postulado":
        sm.ya_en_state += 1
        logger.info("job_id=%s ya postulado (state.db), se omite", card.job_id)
        return

    ctx.db.upsert(card.job_id, card.title, card.url, "visto")

    if card.applied_on_site:
        _save(ctx, card, "postulado")
        sm.ya_postulados += 1
        log_job(logger, card.job_id, card.title, None, "postulado", "figura como postulado en el listado")
        return

    s = ctx.settings
    # Antes de abrir la tarjeta: un título ajeno al perfil se descarta sin clic ni lectura de descripción.
    problem = title_problem(
        card.title,
        title_keywords=s.title_keywords,
        required_keywords=s.required_title_keywords,
    )
    if problem:
        _save(ctx, card, "descartado", error=problem)
        sm.descartados += 1
        log_job(logger, card.job_id, card.title, None, "descartado", problem)
        return

    page_ms = s.page_timeout * 1000
    description: str | None = None
    problem: str | None = None
    try:
        open_card(ctx.page, card.job_id, page_ms)
        description = read_description(ctx.page, card.job_id, page_ms)
        if description is None:
            problem = "el panel de detalle no apareció"
    except (CardNotFoundError, PlaywrightTimeoutError) as exc:
        problem = f"no se pudo abrir el aviso en el listado: {exc}"
    if problem is not None:
        _record(ctx, card, Plan("descartar"), ApplyResult("error", error=problem))
        human_pause(s.delay_min, s.delay_max)
        return
    logger.info("job_id=%s descripción leída: %d caracteres | %s", card.job_id, len(description), description[:120])

    plan = plan_job(card.title, card.location, description, ctx.settings)
    if plan.action == "descartar":
        _save(ctx, card, "descartado", error=plan.motivo)
        sm.descartados += 1
        log_job(logger, card.job_id, card.title, None, "descartado", plan.motivo)
        return

    result = run_apply(
        ctx.page,
        card,
        plan.cv_label,
        ctx.responses,
        dry_run=ctx.dry_run,
        page_timeout=s.page_timeout,
        captcha_timeout=s.captcha_timeout,
        salary=plan.salary,
        home=s.home,
    )
    _record(ctx, card, plan, result)
    human_pause(s.delay_min, s.delay_max)


def run_searches(ctx: RunContext, selected: Sequence[tuple[int, Mapping[str, Any]]]) -> None:
    for index, search in selected:
        if ctx.done:
            break
        url = str(search["url"])
        logger.info("=== Búsqueda %d: %s", index, url)
        s = ctx.settings
        try:
            # Perezoso: cada tarjeta se procesa en el listado, con el panel del aviso abierto a la derecha.
            # Ningún paso navega fuera del listado, así que el generador puede seguir paginando.
            for card in iter_jobs(ctx.page, url, s.max_pages, s.captcha_timeout):
                if ctx.done:
                    break
                process_card(ctx, card)
        except (CaptchaTimeoutError, PageLoadTimeoutError, PlaywrightTimeoutError) as exc:
            ctx.summary.searches_error += 1
            logger.error("Búsqueda %d interrumpida: %s", index, exc)
            continue
        ctx.summary.searches_ok += 1


# ---------------------------------------------------------------------------
# Punto de entrada
# ---------------------------------------------------------------------------


def legacy_paths() -> ProfilePaths:
    """Rutas de la raíz (perfil ``default``), leídas de las constantes del módulo en cada llamada.

    Leer las constantes al llamar (no al importar) hace que los ``monkeypatch`` de los tests sigan valiendo.
    """
    return ProfilePaths(
        name=DEFAULT_PROFILE,
        root=BASE_DIR,
        config=CONFIG_PATH,
        responses=RESPONSES_PATH,
        profile_json=BASE_DIR / "profile.json",
        state_db=STATE_DB_PATH,
        pendientes=PENDIENTES_PATH,
        report=PENDIENTES_REPORT_PATH,
        browser_dir=PROFILE_DIR,
        log_dir=LOG_DIR,
    )


def resolve_run_paths(name: str | None) -> ProfilePaths:
    """``None``/``default`` => raíz; otro => ``profiles/<name>/`` (ProfileError si no es válido o no existe)."""
    if name is None or name == DEFAULT_PROFILE:
        return legacy_paths()
    return require_existing_profile(named_paths(BASE_DIR, name))


def write_pending_report(
    db: StateDB,
    settings: Settings,
    responses: Sequence[Mapping[str, str]],
    paths: ProfilePaths | None = None,
) -> None:
    """Deduplica pendientes.csv y regenera pendientes_resumen.md. Un fallo acá nunca tapa el resumen de la corrida."""
    csv_path = paths.pendientes if paths else PENDIENTES_PATH
    report_path = paths.report if paths else PENDIENTES_REPORT_PATH
    profile_keywords = list(settings.required_title_keywords)
    for rule in settings.cv_rules:
        profile_keywords += list(rule.get("keywords") or [])
    try:
        stats = update_pending_files(
            csv_path,
            report_path,
            responses,
            job_status=db.statuses(),
            desc_keywords=settings.desc_keywords,
            profile_keywords=profile_keywords,
            home=settings.home,
        )
    except Exception as exc:  # el reporte es informativo
        logger.warning("No se pudo generar %s: %s", report_path.name, exc)
        return
    logger.info(
        "%s: %d preguntas por resolver (%d avisos bloqueados), %d ya cubiertas por responses.json",
        report_path.name, stats.open_questions, stats.blocked_jobs, stats.covered_questions,
    )


def print_summary(
    ctx: RunContext,
    log_file: Path,
    searches_total: int,
    paths: ProfilePaths | None = None,
) -> None:
    sm = ctx.summary
    used = ctx.db.get_daily_count()
    limit = ctx.settings.daily_limit
    state_path = paths.state_db if paths else STATE_DB_PATH
    csv_path = paths.pendientes if paths else PENDIENTES_PATH
    report_path = paths.report if paths else PENDIENTES_REPORT_PATH
    logger.info("=" * 60)
    logger.info("RESUMEN (%s)", "dry-run" if ctx.dry_run else "corrida real")
    logger.info("Postulados: %d | Ya postulados: %d | Dry-run OK: %d", sm.postulados, sm.ya_postulados, sm.dry_run_ok)
    logger.info("Pendientes (pregunta sin regla): %d | Descartados: %d | Errores: %d", sm.pendientes, sm.descartados, sm.errores)
    logger.info("Omitidos (ya postulados en state.db): %d | Repetidos en la corrida: %d", sm.ya_en_state, sm.repetidos_en_corrida)
    logger.info("Búsquedas: %d OK, %d con error, de %d", sm.searches_ok, sm.searches_error, searches_total)
    logger.info("Tope diario: %d/%d usadas hoy (restantes %d)", used, limit, max(0, limit - used))
    logger.info("Motivo de cierre: %s", sm.stop_reason)
    logger.info("Log: %s | state.db: %s | pendientes.csv: %s", log_file, state_path, csv_path)
    logger.info("Preguntas sin regla, agrupadas y con plantillas: %s", report_path)
    logger.info("=" * 60)


def _check_bundle_config(files: Mapping[str, bytes]) -> None:
    """Valida config.yaml y responses.json del bundle con los mismos parsers que usa la corrida. ConfigError si no."""
    try:
        raw = yaml.safe_load(files["config.yaml"].decode("utf-8")) or {}
    except (UnicodeDecodeError, yaml.YAMLError) as exc:
        raise ConfigError(f"config.yaml no se pudo leer: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError("config.yaml debe ser un mapa YAML")
    parse_settings(raw)
    try:
        data = json.loads(files["responses.json"].decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ConfigError(f"responses.json no se pudo leer: {exc}") from exc
    parse_responses(data)


def import_bundle_command(zip_path: str, profile: str | None, force: bool) -> int:
    """--import-bundle: valida todo el bundle antes de escribir; un error no deja archivos nuevos."""
    try:
        bundle = read_bundle(Path(zip_path), slug_override=profile)
        _check_bundle_config(bundle.files)
        paths = named_paths(BASE_DIR, bundle.slug)
        written = install_bundle(bundle, paths, force=force)
    except ProfileError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_CONFIG
    except (ConfigError, ValueError, yaml.YAMLError) as exc:
        print(f"Error: configuración inválida en el bundle; no se escribió nada: {exc}", file=sys.stderr)
        return EXIT_CONFIG
    except OSError as exc:
        print(f"Error: no se pudo escribir el perfil: {exc}", file=sys.stderr)
        return EXIT_CONFIG

    print(f"Perfil '{bundle.slug}' instalado en {paths.root}:")
    for path in written:
        print(f"  - {path.name}")
    print("Próximos pasos:")
    print(f"  python main.py --profile {bundle.slug} --login")
    print(f"  python main.py --profile {bundle.slug} --dry-run --limit 3")
    return EXIT_OK


LOGIN_PAGE_TIMEOUT = 60  # s: carga de la página de login (no es la de postulaciones)


def login_command(
    profile: str | None,
    *,
    wait: Callable[[str], str] = input,
    opener: Callable[..., Any] | None = None,
) -> int:
    """--login: abre el navegador visible del perfil en el login y guarda la sesión al cerrar.

    Espera a que el usuario inicie sesión y presione Enter en la terminal; después verifica que la
    página ya no sea el login (si lo es, sale con EXIT_SESSION) y cierra el contexto, que escribe
    cookies y sesión en ``browser/`` del perfil. No postula ni toca ``state.db``.
    """
    try:
        paths = resolve_run_paths(profile)  # perfil nombrado debe existir: no se crea uno nuevo
    except ProfileError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_CONFIG

    session = (opener or open_context)(paths.browser_dir, LOGIN_PAGE_TIMEOUT)
    try:
        try:
            safe_goto(session.page, LOGIN_PAGE_URL)
        except PageLoadTimeoutError as exc:
            print(f"Error: {exc}. Revisá la conexión y volvé a ejecutar --login.", file=sys.stderr)
            return EXIT_SESSION

        print(f"Navegador abierto en el login (perfil '{paths.name}').")
        print("Iniciá sesión en la ventana del navegador. Cuando termines, volvé acá y presioná Enter.")
        wait("> ")

        try:
            check_session(session.page)
        except SessionExpiredError as exc:
            print(f"No se guardó la sesión: todavía no parece haber sesión iniciada ({exc}).", file=sys.stderr)
            print(f"Volvé a ejecutar: python main.py --profile {paths.name} --login", file=sys.stderr)
            return EXIT_SESSION
        except PlaywrightError as exc:  # la ventana se cerró antes de confirmar la sesión
            print(f"No se pudo verificar la sesión ({exc}). Volvé a ejecutar --login.", file=sys.stderr)
            return EXIT_SESSION

        print(f"Sesión guardada en {paths.browser_dir}.")
        return EXIT_OK
    except KeyboardInterrupt:
        print("Interrumpido: la sesión no se guardó si no llegaste a confirmar el inicio.", file=sys.stderr)
        return EXIT_INTERRUPTED
    finally:
        session.close()


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)  # --help sale acá, antes de tocar disco o navegador

    if args.list_profiles:
        others = [
            flag
            for flag, given in (
                ("--dry-run", args.dry_run),
                ("--limit", args.limit is not None),
                ("--search", args.search is not None),
                ("--import-bundle", args.import_bundle is not None),
                ("--force", args.force),
                ("--login", args.login),
            )
            if given
        ]
        if others:
            print(f"Error: --list-profiles no se combina con {', '.join(others)}", file=sys.stderr)
            return EXIT_CONFIG
        print(DEFAULT_PROFILE)
        for name in list_profiles(BASE_DIR):
            print(name)
        return EXIT_OK

    if args.login:
        used = [
            flag
            for flag, given in (
                ("--dry-run", args.dry_run),
                ("--limit", args.limit is not None),
                ("--search", args.search is not None),
                ("--import-bundle", args.import_bundle is not None),
                ("--force", args.force),
            )
            if given
        ]
        if used:
            print(f"Error: --login no se combina con {', '.join(used)}", file=sys.stderr)
            return EXIT_CONFIG
        return login_command(args.profile)

    if args.import_bundle is not None:
        used = [
            flag
            for flag, given in (
                ("--dry-run", args.dry_run),
                ("--limit", args.limit is not None),
                ("--search", args.search is not None),
            )
            if given
        ]
        if used:
            print(f"Error: --import-bundle no se combina con {', '.join(used)}", file=sys.stderr)
            return EXIT_CONFIG
        return import_bundle_command(args.import_bundle, args.profile, args.force)
    if args.force:
        print("Error: --force solo aplica con --import-bundle", file=sys.stderr)
        return EXIT_CONFIG

    try:
        paths = resolve_run_paths(args.profile)
    except ProfileError as exc:  # antes de crear logs: un perfil inexistente no deja carpetas
        print(f"Error: {exc}", file=sys.stderr)
        return EXIT_CONFIG
    log_file = setup_logging(paths.log_dir)

    try:
        settings = load_settings(paths.config)
        responses = load_responses(paths.responses)
        selected = select_searches(settings.searches, args.search)
    except ConfigError as exc:
        logger.error("Configuración inválida: %s", exc)
        return EXIT_CONFIG
    warn_incomplete_rules(responses)

    # Perfil nombrado: los fallos de Playwright van a su carpeta. La raíz conserva la ruta de apply.py.
    previous_failure_dir = apply.FAILURE_DIR
    if paths.name != DEFAULT_PROFILE:
        apply.FAILURE_DIR = paths.failure_dir
    try:
        return _run(args, paths, settings, responses, selected, log_file)
    finally:
        apply.FAILURE_DIR = previous_failure_dir


def _run(
    args: argparse.Namespace,
    paths: ProfilePaths,
    settings: Settings,
    responses: list[dict[str, str]],
    selected: Sequence[tuple[int, Mapping[str, Any]]],
    log_file: Path,
) -> int:
    exit_code = EXIT_OK
    with StateDB(paths.state_db) as db:
        remaining = db.remaining_quota(settings.daily_limit)
        if remaining == 0:
            db.mark_limit_reached()
            logger.warning("Tope diario de %d postulaciones ya alcanzado hoy. No se hace nada.", settings.daily_limit)
            return EXIT_OK

        cap = remaining if args.limit is None else min(args.limit, remaining)
        logger.info(
            "Modo %s | perfil %s | tope diario restante %d | máximo de esta corrida %d | búsquedas %d",
            "dry-run" if args.dry_run else "REAL", paths.name, remaining, cap, len(selected),
        )

        session = open_context(paths.browser_dir, settings.page_timeout)
        ctx = RunContext(
            page=session.page,
            db=db,
            settings=settings,
            responses=responses,
            dry_run=args.dry_run,
            cap=cap,
            paths=paths,
        )
        try:
            run_searches(ctx, selected)
        except SessionExpiredError as exc:
            ctx.summary.stop_reason = f"sesión expirada: {exc}"
            logger.error("Sesión expirada. Volvé a loguearte en el perfil y re-ejecutá: %s", exc)
            exit_code = EXIT_SESSION
        except KeyboardInterrupt:
            ctx.summary.stop_reason = "interrumpido por el usuario"
            logger.warning("Interrumpido por el usuario. El estado de los avisos ya procesados quedó guardado.")
            exit_code = EXIT_INTERRUPTED
        finally:
            session.close()
            write_pending_report(db, settings, responses, paths)
            print_summary(ctx, log_file, len(selected), paths)

    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
