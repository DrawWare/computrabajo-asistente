"""Perfiles aislados (V2, sub-tarea 6.1.1): rutas por perfil y validación de nombres.

``default`` = la raíz de computrabajo_bot/ (compatibilidad total con la configuración actual).
Cualquier otro nombre vive en ``profiles/<slug>/``. Calcula rutas y valida nombres; ``list_profiles``
lee el disco. Importación de bundles del wizard (6.1.3): ``read_bundle`` valida el zip en memoria y
``install_bundle`` escribe solo los archivos del bundle dentro de ``profiles/<slug>/``.
"""

from __future__ import annotations

import json
import re
import shutil
import unicodedata
import zipfile
import zlib
from dataclasses import dataclass
from pathlib import Path, PurePosixPath, PureWindowsPath

SLUG_RE = re.compile(r"[a-z0-9][a-z0-9-]{1,31}")
DEFAULT_PROFILE = "default"
SLUG_MAX_LEN = 32

BUNDLE_FILES = ("profile.json", "config.yaml", "responses.json", "LEEME.txt")
# V3.5: scripts de instalación que el asistente agrega al zip. Se aceptan y se descartan: no se instalan en el perfil.
SCRIPT_FILES = ("instalar_y_configurar.bat", "iniciar_bot.bat", "instalar_y_configurar.sh", "iniciar_bot.sh")
REQUIRED_BUNDLE_FILES = ("profile.json", "config.yaml", "responses.json")
MAX_BUNDLE_BYTES = 2_000_000
BUNDLE_VERSION = 1


class ProfileError(ValueError):
    """Nombre de perfil inválido o perfil inexistente."""


@dataclass(frozen=True)
class ProfilePaths:
    name: str
    root: Path
    config: Path
    responses: Path
    profile_json: Path
    state_db: Path
    pendientes: Path
    report: Path
    browser_dir: Path  # user_data_dir de Chromium (sesión de Computrabajo)
    log_dir: Path

    @property
    def failure_dir(self) -> Path:
        return self.log_dir / "fallos"


def validate_slug(name: str) -> str:
    """Devuelve ``name`` si es un slug válido distinto de ``default``; si no, ProfileError."""
    if not isinstance(name, str) or not SLUG_RE.fullmatch(name):
        raise ProfileError(
            f"nombre de perfil inválido: {name!r} (usá de 2 a 32 letras minúsculas, números o guiones)"
        )
    if name == DEFAULT_PROFILE:
        raise ProfileError(f"'{DEFAULT_PROFILE}' es el nombre reservado de la raíz del bot")
    return name


def slugify(text: str) -> str:
    """'María José Gómez' -> 'maria-jose-gomez'. Sin tildes, minúsculas, guiones, máx. 32; '' si no queda nada."""
    decomposed = unicodedata.normalize("NFKD", text or "")
    ascii_text = "".join(ch for ch in decomposed if not unicodedata.combining(ch)).lower()
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_text).strip("-")
    return slug[:SLUG_MAX_LEN].rstrip("-")


def _paths(name: str, root: Path, browser_dir: Path, log_dir: Path) -> ProfilePaths:
    return ProfilePaths(
        name=name,
        root=root,
        config=root / "config.yaml",
        responses=root / "responses.json",
        profile_json=root / "profile.json",
        state_db=root / "state.db",
        pendientes=root / "pendientes.csv",
        report=root / "pendientes_resumen.md",
        browser_dir=browser_dir,
        log_dir=log_dir,
    )


def default_paths(base_dir: str | Path) -> ProfilePaths:
    """Rutas de la raíz (perfil ``default``): exactamente las que usa main.py hoy."""
    base = Path(base_dir)
    return _paths(DEFAULT_PROFILE, base, base / "profile", base / "logs")


def named_paths(base_dir: str | Path, slug: str) -> ProfilePaths:
    """Rutas de ``profiles/<slug>/``. ProfileError si el slug no es válido."""
    validate_slug(slug)
    root = Path(base_dir) / "profiles" / slug
    return _paths(slug, root, root / "browser", root / "logs")


def resolve_profile(name: str | None, base_dir: str | Path) -> ProfilePaths:
    """``None`` o ``"default"`` => raíz; cualquier otro => ``profiles/<name>/``."""
    if name is None or name == DEFAULT_PROFILE:
        return default_paths(base_dir)
    return named_paths(base_dir, name)


def require_existing_profile(paths: ProfilePaths) -> ProfilePaths:
    """Perfiles nombrados deben tener ``config.yaml``; si no, ProfileError. La raíz se valida al cargar config."""
    if paths.name != DEFAULT_PROFILE and not paths.config.is_file():
        raise ProfileError(f"no existe el perfil '{paths.name}' (falta {paths.config})")
    return paths


def list_profiles(base_dir: str | Path) -> list[str]:
    """Slugs de ``profiles/`` que tienen ``config.yaml``, ordenados. [] si no existe la carpeta."""
    folder = Path(base_dir) / "profiles"
    if not folder.is_dir():
        return []
    return sorted(
        child.name
        for child in folder.iterdir()
        if child.is_dir() and SLUG_RE.fullmatch(child.name) and (child / "config.yaml").is_file()
    )


@dataclass(frozen=True)
class Bundle:
    """Contenido validado de un ``perfil_<slug>.zip`` del wizard: nombre -> bytes, más ``profile.json`` parseado."""

    slug: str
    files: dict[str, bytes]
    profile: dict


def _check_bundle_name(name: str) -> None:
    if (
        "/" in name
        or "\\" in name
        or ".." in name
        or PurePosixPath(name).is_absolute()
        or PureWindowsPath(name).is_absolute()
        or (name not in BUNDLE_FILES and name not in SCRIPT_FILES)
    ):
        raise ProfileError(f"entrada no permitida en el bundle: {name!r}")


def _read_bundle_dir(path: Path) -> dict[str, bytes]:
    """V3.5: archivos del bundle desde una carpeta descomprimida. Solo lee BUNDLE_FILES; ignora el resto."""
    files: dict[str, bytes] = {}
    total = 0
    for name in BUNDLE_FILES:
        item = path / name
        if not item.is_file():
            continue
        total += item.stat().st_size
        if total > MAX_BUNDLE_BYTES:
            raise ProfileError(f"bundle demasiado grande (máximo {MAX_BUNDLE_BYTES} bytes)")
        files[name] = item.read_bytes()
    return files


def read_bundle(zip_path: str | Path, slug_override: str | None = None) -> Bundle:
    """Lee y valida un bundle (zip o carpeta descomprimida) sin escribir nada en disco. ProfileError si es inválido."""
    path = Path(zip_path)
    if path.is_dir():
        return _validate_bundle(_read_bundle_dir(path), slug_override)
    try:
        archive = zipfile.ZipFile(path)
    except zipfile.BadZipFile as exc:
        raise ProfileError(f"no es un zip válido: {path.name}") from exc
    except OSError as exc:
        raise ProfileError(f"no se pudo abrir {path}: {exc}") from exc

    with archive:
        infos = archive.infolist()
        seen: set[str] = set()
        for info in infos:
            _check_bundle_name(info.filename)
            if info.filename in seen:
                raise ProfileError(f"entrada duplicada en el bundle: {info.filename!r}")
            seen.add(info.filename)
        if sum(info.file_size for info in infos) > MAX_BUNDLE_BYTES:
            raise ProfileError(f"bundle demasiado grande (máximo {MAX_BUNDLE_BYTES} bytes descomprimidos)")

        files: dict[str, bytes] = {}
        total = 0
        for info in infos:
            try:
                with archive.open(info) as handle:
                    data = handle.read(MAX_BUNDLE_BYTES - total + 1)
            except (zipfile.BadZipFile, RuntimeError, NotImplementedError, zlib.error) as exc:
                raise ProfileError(f"bundle dañado o no soportado ({info.filename}): {exc}") from exc
            total += len(data)
            if total > MAX_BUNDLE_BYTES:
                raise ProfileError(f"bundle demasiado grande (máximo {MAX_BUNDLE_BYTES} bytes descomprimidos)")
            if info.filename not in SCRIPT_FILES:  # los scripts no se instalan en el perfil
                files[info.filename] = data

    return _validate_bundle(files, slug_override)


def _validate_bundle(files: dict[str, bytes], slug_override: str | None) -> Bundle:
    missing = [name for name in REQUIRED_BUNDLE_FILES if name not in files]
    if missing:
        raise ProfileError(f"faltan archivos en el bundle: {', '.join(missing)}")

    try:
        profile = json.loads(files["profile.json"].decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProfileError(f"profile.json inválido: {exc}") from exc
    if not isinstance(profile, dict):
        raise ProfileError("profile.json debe ser un objeto JSON")

    version = profile.get("bundle_version")
    if isinstance(version, bool) or version != BUNDLE_VERSION:
        raise ProfileError(f"bundle_version no soportado: {version!r} (se espera {BUNDLE_VERSION})")

    slug = validate_slug(slug_override if slug_override is not None else profile.get("slug"))
    return Bundle(slug=slug, files=files, profile=profile)


def install_bundle(bundle: Bundle, paths: ProfilePaths, force: bool = False) -> list[Path]:
    """Escribe los archivos del bundle en ``paths.root``. Devuelve las rutas escritas.

    Si ya existe ``config.yaml`` o ``responses.json`` exige ``force``; con ``force`` guarda ``.bak`` de ambos.
    Nunca toca ``state.db``, ``pendientes.csv``, ``browser/`` ni ``logs/``.
    """
    unknown = [name for name in bundle.files if name not in BUNDLE_FILES]
    if unknown:
        raise ProfileError(f"archivos fuera del bundle: {', '.join(unknown)}")

    existing = [path for path in (paths.config, paths.responses) if path.exists()]
    if existing and not force:
        raise ProfileError(
            f"el perfil '{bundle.slug}' ya existe ({paths.config.name} presente); usá --force para reemplazarlo"
        )

    paths.root.mkdir(parents=True, exist_ok=True)
    for path in existing:
        shutil.copyfile(path, path.with_name(path.name + ".bak"))

    written: list[Path] = []
    for name in BUNDLE_FILES:
        if name in bundle.files:
            target = paths.root / name
            target.write_bytes(bundle.files[name])
            written.append(target)
    return written
