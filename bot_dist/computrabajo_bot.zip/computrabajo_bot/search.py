"""Recorre el listado de una búsqueda, genera las tarjetas y abre cada aviso en el panel (tarea 4.1).

``iter_jobs`` es generador: lee las tarjetas de una página, las entrega una a una y recién después
pasa a la siguiente página con ``PAGINATION_NEXT``. Entre entrega y entrega el consumidor puede abrir
avisos en el panel derecho (``open_card``) sin que el listado cambie de URL.
No decide nada sobre dedupe ni filtros: eso lo hace main.py.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Iterator
from urllib.parse import urljoin, urlsplit, urlunsplit

from playwright.sync_api import Page, TimeoutError as PlaywrightTimeoutError

import page_selectors as sel
from browser import check_session, safe_goto, wait_captcha_if_present

logger = logging.getLogger(__name__)

_HEX_ID_RE = re.compile(r"[0-9A-Fa-f]{20,}")

# Distancia en píxeles al borde derecho de la tarjeta donde se hace clic: el título es un link
# (``JOB_CARD_LINK``) y clicarlo navegaría fuera del listado.
_CLICK_INSET_PX = 10


class CardNotFoundError(RuntimeError):
    """La tarjeta del aviso no está visible en el listado (no se pudo abrir el panel)."""


@dataclass(frozen=True)
class JobCard:
    job_id: str
    title: str
    url: str
    applied_on_site: bool  # True si la tarjeta ya muestra "Postulado"
    location: str = ""  # ubicación + modalidad tal como aparecen en la tarjeta (para filters.evaluate_job)


def css_attr(value: str) -> str:
    """Valor entre comillas para un selector CSS de atributo (escapa barra invertida y comillas)."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def clean_job_url(href: str, base: str) -> str:
    """URL absoluta del aviso, sin fragmento (#lc=...) ni query."""
    absolute = urljoin(base, href)
    parts = urlsplit(absolute)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))


def job_id_from_url(url: str) -> str:
    """Respaldo cuando la tarjeta no tiene ``data-id``: id hex de la URL, o el slug final."""
    path = urlsplit(url).path.rstrip("/")
    match = _HEX_ID_RE.search(path)
    if match:
        return match.group(0).upper()
    return path.rsplit("/", 1)[-1]


def _read_page_cards(page: Page, seen: set[str]) -> list[JobCard]:
    """Tarjetas de la página actual que no están en ``seen`` (y las marca como vistas)."""
    cards = page.locator(sel.JOB_CARD)
    found: list[JobCard] = []
    for index in range(cards.count()):
        card = cards.nth(index)
        link = card.locator(sel.JOB_CARD_LINK).first
        href = link.get_attribute("href") or ""
        if not href:
            continue
        url = clean_job_url(href, page.url)
        job_id = (card.get_attribute(sel.JOB_CARD_ID_ATTR) or "").strip() or job_id_from_url(url)
        if job_id in seen:  # la misma tarjeta puede aparecer dos veces (estado "sel")
            continue
        seen.add(job_id)

        title = " ".join((link.inner_text() or "").split())
        applied = card.locator(sel.JOB_CARD_APPLIED_TAG).count() > 0
        location = " ".join(
            " ".join(t.split()) for t in card.locator(sel.JOB_CARD_LOCATION).all_inner_texts() if t.strip()
        )
        found.append(JobCard(job_id=job_id, title=title, url=url, applied_on_site=applied, location=location))
    return found


def iter_jobs(page: Page, search_url: str, max_pages: int, captcha_timeout: float = 180) -> Iterator[JobCard]:
    """Genera ``JobCard`` recorriendo hasta ``max_pages`` páginas del listado.

    Las tarjetas de cada página se leen completas antes de entregar la primera: abrir un aviso
    cambia el DOM del panel, no el listado de metadatos ya leído.
    Lanza SessionExpiredError / CaptchaTimeoutError / PageLoadTimeoutError: las maneja main.py.
    """
    safe_goto(page, search_url)
    check_session(page)
    wait_captcha_if_present(page, captcha_timeout)

    seen: set[str] = set()
    for page_number in range(1, max_pages + 1):
        page_cards = _read_page_cards(page, seen)
        logger.info("Listado pág. %d: %d tarjetas nuevas (%s)", page_number, len(page_cards), page.url)
        yield from page_cards

        next_link = page.locator(sel.PAGINATION_NEXT).first
        if page_number == max_pages or next_link.count() == 0:
            break
        target = next_link.get_attribute("data-path")
        if not target:
            break
        safe_goto(page, urljoin(page.url, target))
        check_session(page)
        wait_captcha_if_present(page, captcha_timeout)


def open_card(page: Page, job_id: str, timeout_ms: float) -> None:
    """Hace clic en la tarjeta del aviso para que su panel de detalle se abra a la derecha.

    No navega: la URL solo cambia a ``#<id>``. Si quedó abierto el cuestionario de otro aviso
    (dry-run), vuelve primero al detalle. Lanza CardNotFoundError si la tarjeta no aparece.
    """
    check_session(page)

    back = page.locator(sel.KQ_BACK_BUTTON)
    if back.count() > 0 and back.first.is_visible():
        back.first.click()

    card = page.locator(f"{sel.JOB_CARD}[{sel.JOB_CARD_ID_ATTR}={css_attr(job_id)}]").first
    try:
        card.wait_for(state="visible", timeout=timeout_ms)
    except PlaywrightTimeoutError as exc:
        raise CardNotFoundError(f"tarjeta {job_id} no visible en el listado") from exc

    box = card.bounding_box()
    if box is None:
        raise CardNotFoundError(f"tarjeta {job_id} sin caja visible")
    card.click(position={"x": max(box["width"] - _CLICK_INSET_PX, 1), "y": _CLICK_INSET_PX})
    logger.debug("Tarjeta %s abierta en el panel", job_id)
