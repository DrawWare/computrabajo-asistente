"""pendientes_resumen.md: resumen accionable de las preguntas sin regla de pendientes.csv.

Agrupa por pregunta (sin tildes ni mayúsculas) los avisos que pasaron los filtros de título y descripción y
quedaron sin postular porque el bot no supo responder una pregunta (sin regla en responses.json y sin
respuesta sugerida por la IA). Por pregunta muestra:
- el tipo de campo: radio/select con sus opciones, o texto con o sin botón IA ("Usar respuesta");
- los avisos que bloquea hoy (título y URL); los que state.db ya tiene postulados o descartados no cuentan;
- una plantilla para pegar en responses.json y, si parece un requisito técnico, la keyword para excluirlo.
Las preguntas que las reglas actuales ya responden van a una tabla aparte ("ya cubiertas").

main.py lo regenera al final de cada corrida. A mano, desde computrabajo_bot/: ``python pending_report.py``
(también deduplica pendientes.csv). Todo es puro salvo ``update_pending_files`` y el bloque ``__main__``.
"""

from __future__ import annotations

import json
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Mapping, Sequence

from dedupe import (
    KIND_OTHER,
    KIND_RADIO,
    KIND_SELECT,
    KIND_TEXT,
    KIND_TEXT_AI_EMPTY,
    KIND_TEXT_NO_AI,
    compact_pendientes,
    dedupe_pendientes,
    question_key,
    read_pendientes,
    split_options,
)
from filters import is_excluded, normalize
from questions import (
    incomplete_rules,
    is_salary_question,
    match_rule,
    parse_salary_range,
    placeholders,
    DEFAULT_HOME,
    HomeLocation,
    resolve_answer,
    residence_yes_no,
)

REPORT_NAME = "pendientes_resumen.md"
RESOLVED_STATUSES = ("postulado", "descartado")  # el aviso ya no espera una respuesta

KIND_LABELS = {
    KIND_RADIO: "radio (opción única)",
    KIND_SELECT: "lista desplegable (select)",
    KIND_TEXT_NO_AI: "texto libre, sin botón IA («Usar respuesta»)",
    KIND_TEXT_AI_EMPTY: "texto libre, con botón IA («Usar respuesta») que no completó el campo",
    KIND_TEXT: "texto libre (fila anterior al registro del botón IA)",
    KIND_OTHER: "tipo de campo que el bot no sabe completar",
    "": "desconocido",
}
_CHOICE_KINDS = (KIND_RADIO, KIND_SELECT)

# Estado de la pregunta frente a las reglas actuales, en orden de prioridad del reporte.
COVERED = "cubierta"
NO_RULE = "sin_regla"
OPTION_MISSING = "opcion_no_encontrada"
INCOMPLETE_RULE = "regla_incompleta"
UNCONFIRMED = "sin_confirmar"
UNSUPPORTED = "no_soportado"
_STATUS_ORDER = (NO_RULE, OPTION_MISSING, INCOMPLETE_RULE, UNCONFIRMED, UNSUPPORTED)


# ---------------------------------------------------------------------------
# Agrupado
# ---------------------------------------------------------------------------


@dataclass
class QuestionGroup:
    question: str  # texto tal como lo mostró el sitio (primera aparición)
    kind: str = ""
    options: list[str] = field(default_factory=list)
    jobs: dict[str, dict[str, str]] = field(default_factory=dict)  # job_id -> {title, url, ts}

    @property
    def first_ts(self) -> str:
        return min((job["ts"] for job in self.jobs.values()), default="")


def _kind_rank(kind: str) -> int:
    return 0 if not kind else 1 if kind == KIND_TEXT else 2


def group_pending(
    rows: Iterable[Mapping[str, str]],
    job_status: Mapping[str, str] | None = None,
) -> tuple[list[QuestionGroup], int]:
    """(grupos por pregunta, filas omitidas porque el aviso ya está postulado o descartado en state.db).

    Solo filas ``pregunta_sin_regla``, deduplicadas por (job_id, pregunta). En cada grupo se queda el tipo
    más informativo y la primera lista de opciones que aparezca.
    """
    status = job_status or {}
    groups: dict[str, QuestionGroup] = {}
    omitted = 0
    for row in dedupe_pendientes(rows):
        if row["motivo"] != "pregunta_sin_regla" or not row["pregunta"]:
            continue
        if status.get(row["job_id"]) in RESOLVED_STATUSES:
            omitted += 1
            continue
        group = groups.setdefault(question_key(row["pregunta"]), QuestionGroup(row["pregunta"]))
        if _kind_rank(row["tipo"]) > _kind_rank(group.kind):
            group.kind = row["tipo"]
        if not group.options:
            group.options = split_options(row["opciones"])
        group.jobs.setdefault(row["job_id"], {"title": row["title"], "url": row["url"], "ts": row["ts"]})
    return list(groups.values()), omitted


# ---------------------------------------------------------------------------
# Cobertura con las reglas actuales
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Coverage:
    status: str
    answer: str | None = None  # cubierta: lo que se enviaría; sin_confirmar: respuesta candidata
    rule_answer: str | None = None  # opcion_no_encontrada: answer de la regla que la captura (la identifica)
    rule_option: str | None = None  # opcion_no_encontrada: opción que busca esa regla
    missing: tuple[str, ...] = ()  # regla_incompleta: placeholders sin completar


def coverage(
    question: str,
    kind: str,
    options: Sequence[str],
    rules: Sequence[Mapping[str, str]],
    home: HomeLocation = DEFAULT_HOME,
) -> Coverage:
    """Qué haría hoy el bot con esta pregunta (sin pretensión del rol: los sueldos usan responses.json)."""
    if kind == KIND_OTHER:
        return Coverage(UNSUPPORTED)
    rule = match_rule(question, rules)
    if kind in _CHOICE_KINDS:
        if options and is_salary_question(question) and any(parse_salary_range(o) for o in options):
            return Coverage(COVERED, "el rango que contiene la pretensión del rol (cv_rules)")
        if options:
            answer = resolve_answer(question, rules, options, home=home)
            if answer is not None:
                return Coverage(COVERED, answer)
            if rule is not None and residence_yes_no(question, home) is None:
                return Coverage(OPTION_MISSING, rule_answer=rule["answer"], rule_option=rule.get("option") or rule["answer"])
        else:
            # Fila vieja sin opciones registradas: hay respuesta candidata, pero no se puede confirmar el radio.
            candidate = residence_yes_no(question, home) or (rule and (rule.get("option") or rule["answer"]))
            if candidate:
                return Coverage(UNCONFIRMED, candidate)
    else:
        answer = resolve_answer(question, rules, home=home)
        if answer is not None:
            return Coverage(COVERED, answer)

    missing = [
        placeholder
        for incomplete in incomplete_rules(rules)
        if re.search(incomplete["pattern"], question, re.IGNORECASE)
        for placeholder in placeholders(incomplete)
    ]
    if missing:
        return Coverage(INCOMPLETE_RULE, missing=tuple(dict.fromkeys(missing)))
    return Coverage(NO_RULE)


# ---------------------------------------------------------------------------
# Sugerencias
# ---------------------------------------------------------------------------

_ACCENT_CLASSES = {"á": "[aá]", "é": "[eé]", "í": "[ií]", "ó": "[oó]", "ú": "[uú]", "ü": "[uü]", "ñ": "[nñ]"}
# Palabras de arranque que no hacen a la pregunta ("¿Tenés experiencia...", "¿Contás con..."): se sacan del
# patrón sugerido para que también matchee otras formas de preguntar lo mismo.
_LEADING_FILLERS = frozenset(
    "tenes tienes tiene contas cuentas cuenta con cual cuales es tu su sos estas se te que podes puedes puede "
    "hay alguna algun vez".split()
)
_MAX_PATTERN_WORDS = 8

_REQUIREMENT_RE = re.compile(
    r"\b(?:experiencia|conocimientos?|manejo|dominio|certificacion|formacion)\b"
    r"(?:\s+(?:previa|comprobable|demostrable|laboral|trabajando|usando))?"
    r"\s+(?:con|en|de|sobre)\s+(?P<term>[^?(),;:¿]+)"
)
_ADVANCED_RE = re.compile(r"\b(?P<term>[a-z]+ avanzad[oa])\b")
_PAREN_RE = re.compile(r"\(([^)]+)\)")


def _word_pattern(word: str) -> str:
    return "".join(_ACCENT_CLASSES.get(char, re.escape(char)) for char in word)


def suggest_pattern(question: str) -> str:
    """Regex acotada y segura para la pregunta: su comienzo literal, sin muletillas iniciales.

    Corta en el primer "(", "?", ",", ":" o ";", deja hasta 8 palabras y escribe las vocales con tilde
    como clase ("inglés" -> "ingl[eé]s"). Siempre matchea la pregunta original.
    """
    head = re.split(r"[(?!,:;]", question.strip().lstrip("¿¡ ").strip(), maxsplit=1)[0]
    words = head.lower().split()
    while len(words) > 2 and normalize(words[0]) in _LEADING_FILLERS:
        words.pop(0)
    return " ".join(_word_pattern(word) for word in words[:_MAX_PATTERN_WORDS])


def rule_template(question: str, kind: str, options: Sequence[str]) -> dict[str, str]:
    """Regla lista para pegar en responses.json, con placeholders: hasta completarlos, el bot la ignora."""
    template = {"pattern": suggest_pattern(question), "answer": "[COMPLETAR_RESPUESTA]"}
    if kind in _CHOICE_KINDS:
        template["option"] = f"[COMPLETAR: {' | '.join(options)}]" if options else "[COMPLETAR_OPCION]"
    return template


def requirement_keywords(question: str, profile_keywords: Iterable[str] = ()) -> list[str]:
    """Keywords para ``exclude_desc_keywords`` si la pregunta pide un requisito puntual ("experiencia con BPA").

    Devuelve el término (y el contenido del paréntesis que lo sigue, si hay) en minúsculas y sin tildes,
    o [] si la pregunta no tiene esa forma o el término es del perfil (keywords de cv_rules / títulos):
    no se sugiere excluir lo que sí se tiene.
    """
    text = normalize(question)
    found = _REQUIREMENT_RE.search(text) or _ADVANCED_RE.search(text)
    if not found:
        return []
    term = " ".join(found.group("term").split()[:4]).strip()
    if not term or is_excluded(term, None, profile_keywords):
        return []
    keywords = [term]
    paren = _PAREN_RE.search(text, found.end("term"))
    if paren and paren.start() - found.end("term") <= 1:
        keywords.append(" ".join(paren.group(1).split()))
    return keywords


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------

_MD_SPECIAL = re.compile(r"([\\`*_\[\]<>|#])")


def _md(text: str) -> str:
    return _MD_SPECIAL.sub(r"\\\1", " ".join((text or "").split()))


def _code(text: str) -> str:
    return f"`{(text or '').replace('`', 'ˋ')}`"


def _short(text: str, limit: int = 90) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _kind_line(group: QuestionGroup) -> str:
    label = KIND_LABELS.get(group.kind, group.kind)
    if group.kind in _CHOICE_KINDS:
        if group.options:
            return f"{label} — opciones: " + " · ".join(_code(o) for o in group.options)
        return f"{label} — opciones no registradas (fila anterior al registro; se ven en la próxima corrida)"
    return label


def _status_line(cov: Coverage) -> str:
    if cov.status == NO_RULE:
        return "ninguna regla de `responses.json` la captura."
    if cov.status == OPTION_MISSING:
        return (
            f"la captura la regla de «{_md(_short(cov.rule_answer or '', 50))}», pero su opción "
            f"{_code(_short(cov.rule_option or '', 50))} no está entre las opciones del aviso."
        )
    if cov.status == INCOMPLETE_RULE:
        return (
            "hay una regla, pero tiene " + ", ".join(_code(p) for p in cov.missing)
            + " sin completar en `responses.json` (el bot la ignora hasta que lo completes)."
        )
    if cov.status == UNCONFIRMED:
        return (
            f"hoy se respondería {_code(_short(cov.answer or '', 60))}, pero no quedaron registradas las "
            "opciones del radio: se confirma en la próxima corrida."
        )
    return "el bot no sabe completar este tipo de campo: revisar el HTML del paso (logs/fallos)."


def _job_lines(group: QuestionGroup) -> list[str]:
    lines = []
    for job_id, job in sorted(group.jobs.items(), key=lambda item: item[1]["ts"]):
        title = _md(job["title"]) or job_id
        link = f"[{title}]({job['url']})" if job["url"] else title
        lines.append(f"  - {link} — {_code(job_id[:8] + '…')} · desde {job['ts'].replace('T', ' ')[:16]}")
    return lines


def _render_open(index: int, group: QuestionGroup, cov: Coverage, desc_keywords: Sequence[str],
                 profile_keywords: Sequence[str]) -> list[str]:
    count = len(group.jobs)
    lines = [
        f"### {index}. {_md(group.question)} — {count} aviso{'s' if count != 1 else ''}",
        "",
        f"- **Tipo:** {_kind_line(group)}",
        f"- **Estado:** {_status_line(cov)}",
        "- **Avisos bloqueados:**",
        *_job_lines(group),
    ]
    if cov.status == UNSUPPORTED:
        return lines + [""]

    if cov.status == INCOMPLETE_RULE:
        lines.append("- **Para responderla:** completá el placeholder en `responses.json`.")
    else:
        where = " (antes de la regla que hoy la captura: gana la primera que matchea)" if cov.status == OPTION_MISSING else ""
        template = json.dumps(rule_template(group.question, group.kind, group.options), ensure_ascii=False, indent=2)
        lines += [
            f"- **Para responderla:** pegá en `responses.json`{where} y reemplazá los `[COMPLETAR…]`:",
            "",
            "  ```json",
            *[f"  {line}" for line in template.splitlines()],
            "  ```",
        ]

    keywords = requirement_keywords(group.question, profile_keywords)
    if keywords:
        configured = {normalize(k) for k in desc_keywords}
        new = [k for k in keywords if normalize(k) not in configured]
        if new:
            lines.append(
                "- **Si es un requisito que no tenés:** agregá "
                + " y ".join(_code(f'"{k}"') for k in new)
                + " a `exclude_desc_keywords` en `config.yaml` (descarta el aviso antes de postular)."
            )
        else:
            lines.append(
                "- **Exclusión:** " + " y ".join(_code(k) for k in keywords)
                + " ya está en `exclude_desc_keywords`: los avisos nuevos con ese texto se descartan solos."
            )
    return lines + [""]


@dataclass(frozen=True)
class ReportStats:
    open_questions: int
    covered_questions: int
    blocked_jobs: int
    omitted_rows: int


def build_report(
    rows: Iterable[Mapping[str, str]],
    rules: Sequence[Mapping[str, str]],
    *,
    job_status: Mapping[str, str] | None = None,
    desc_keywords: Sequence[str] = (),
    profile_keywords: Sequence[str] = (),
    now: datetime | None = None,
    home: HomeLocation = DEFAULT_HOME,
) -> tuple[str, ReportStats]:
    """Markdown del resumen y sus números. ``rows`` = filas de pendientes.csv (cualquier formato)."""
    rows = list(rows)
    groups, omitted = group_pending(rows, job_status)
    evaluated = [(group, coverage(group.question, group.kind, group.options, rules, home)) for group in groups]
    open_items = sorted(
        ((g, c) for g, c in evaluated if c.status != COVERED),
        key=lambda item: (_STATUS_ORDER.index(item[1].status), -len(item[0].jobs), item[0].first_ts),
    )
    covered = sorted(((g, c) for g, c in evaluated if c.status == COVERED), key=lambda item: -len(item[0].jobs))
    blocked = {job_id for group, _ in open_items for job_id in group.jobs}
    stats = ReportStats(len(open_items), len(covered), len(blocked), omitted)

    stamp = (now or datetime.now()).strftime("%Y-%m-%d %H:%M")
    lines = [
        "# Pendientes: preguntas sin regla",
        "",
        f"_Generado {stamp} por `pending_report.py` a partir de `pendientes.csv`. No lo edites: se regenera al "
        "final de cada corrida de `main.py` (o con `python pending_report.py`)._",
        "",
        "Avisos que pasaron los filtros de título y descripción pero quedaron sin postular porque el bot no supo "
        "responder una pregunta (sin regla en `responses.json` y sin respuesta sugerida por la IA). Los avisos en "
        "`pendiente` se reintentan en cada corrida: con la regla agregada, se postulan en la próxima. En "
        "`responses.json` gana la primera regla que matchea: pegá las específicas antes que las generales.",
        "",
        f"**Resumen:** {stats.open_questions} pregunta{'s' if stats.open_questions != 1 else ''} por resolver · "
        f"{stats.blocked_jobs} aviso{'s' if stats.blocked_jobs != 1 else ''} bloqueado{'s' if stats.blocked_jobs != 1 else ''} · "
        f"{stats.covered_questions} ya cubierta{'s' if stats.covered_questions != 1 else ''} por las reglas actuales · "
        f"{len(dedupe_pendientes(rows))} filas únicas en `pendientes.csv` ({omitted} de avisos que hoy ya están "
        "postulados o descartados en `state.db`, fuera del conteo).",
        "",
    ]
    for incomplete in incomplete_rules(rules):
        lines += [
            "> **Falta completar en `responses.json`:** " + ", ".join(_code(p) for p in placeholders(incomplete))
            + f" en la regla «{_md(_short(incomplete['answer'], 60))}». Hasta entonces el bot no la usa.",
            "",
        ]
    lines += ["## Por resolver", ""]
    if not open_items:
        lines += ["Nada por resolver: todas las preguntas registradas tienen respuesta con las reglas actuales.", ""]
    for index, (group, cov) in enumerate(open_items, start=1):
        lines += _render_open(index, group, cov, desc_keywords, profile_keywords)

    if covered:
        lines += [
            "## Ya cubiertas por las reglas actuales",
            "",
            "Se responden solas en la próxima corrida; no hace falta tocar nada.",
            "",
            "| Pregunta | Tipo | Avisos | Respuesta que se enviaría |",
            "|---|---|---|---|",
        ]
        for group, cov in covered:
            kind = KIND_LABELS.get(group.kind, group.kind).split(",")[0].split(" (")[0]
            lines.append(f"| {_md(group.question)} | {kind} | {len(group.jobs)} | {_md(_short(cov.answer or ''))} |")
        lines.append("")
    return "\n".join(lines), stats


# ---------------------------------------------------------------------------
# Archivos
# ---------------------------------------------------------------------------


def update_pending_files(
    csv_path: Path,
    report_path: Path,
    rules: Sequence[Mapping[str, str]],
    *,
    job_status: Mapping[str, str] | None = None,
    desc_keywords: Sequence[str] = (),
    profile_keywords: Sequence[str] = (),
    home: HomeLocation = DEFAULT_HOME,
) -> ReportStats:
    """Deduplica pendientes.csv (si hace falta) y reescribe el resumen en Markdown.

    Si el CSV no se puede reescribir (p. ej. abierto en Excel), el resumen se genera igual: la lectura ya
    deduplica. OSError solo si no se puede escribir el resumen.
    """
    try:
        compact_pendientes(csv_path)
    except OSError:
        pass  # la deduplicación del archivo queda para la próxima; el resumen no la necesita
    text, stats = build_report(
        read_pendientes(csv_path),
        rules,
        job_status=job_status,
        desc_keywords=desc_keywords,
        profile_keywords=profile_keywords,
        home=home,
    )
    report_path.write_text(text, encoding="utf-8")
    return stats


def profile_keywords_from_config(raw: Mapping) -> list[str]:
    """Keywords del perfil (cv_rules + required_title_keywords): no se sugiere excluirlas."""
    keywords = list(raw.get("required_title_keywords") or [])
    for rule in raw.get("cv_rules") or []:
        keywords += list(rule.get("keywords") or [])
    return keywords


def _main(argv: Sequence[str] | None = None) -> int:
    import argparse

    import yaml

    from dedupe import StateDB
    from location_config import parse_location
    from profiles import ProfileError, require_existing_profile, resolve_profile

    parser = argparse.ArgumentParser(description="Deduplica pendientes.csv y regenera pendientes_resumen.md.")
    parser.add_argument("--profile", metavar="NAME", default=None, help="perfil aislado en profiles/NAME/ (sin la opción: raíz)")
    args = parser.parse_args(argv)

    base = Path(__file__).resolve().parent
    try:
        paths = require_existing_profile(resolve_profile(args.profile, base))
    except ProfileError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    rules = json.loads(paths.responses.read_text(encoding="utf-8"))
    config = yaml.safe_load(paths.config.read_text(encoding="utf-8")) or {}
    try:
        _, home = parse_location(config)
    except ValueError as exc:
        print(f"Error: configuración inválida en {paths.config.name}: {exc}", file=sys.stderr)
        return 1
    job_status: dict[str, str] = {}
    if paths.state_db.exists():
        with StateDB(paths.state_db) as db:
            job_status = db.statuses()
    csv_path = paths.pendientes
    before = len(read_pendientes(csv_path))
    stats = update_pending_files(
        csv_path,
        paths.report,
        rules,
        job_status=job_status,
        desc_keywords=list(config.get("exclude_desc_keywords") or []),
        profile_keywords=profile_keywords_from_config(config),
        home=home,
    )
    after = len(read_pendientes(csv_path))
    print(
        f"pendientes.csv: {before} -> {after} filas | {REPORT_NAME}: {stats.open_questions} preguntas por resolver "
        f"({stats.blocked_jobs} avisos), {stats.covered_questions} ya cubiertas, {stats.omitted_rows} filas de "
        "avisos postulados/descartados fuera del conteo"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
