# Perfiles

Cada carpeta de esta lista es un perfil aislado (config, respuestas, estado, sesión de Computrabajo). Su contenido
es personal y está ignorado por git; solo este README se versiona.
